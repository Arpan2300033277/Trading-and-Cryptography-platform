// Enhanced WebSocket client with reconnection logic and subscription management
type MarketData = {
  symbol: string
  price: number
  change: number
}

type OrderBookUpdate = {
  symbol: string
  asks: Array<[number, number]>
  bids: Array<[number, number]>
}

type TradeUpdate = {
  id: string
  symbol: string
  price: number
  amount: number
  side: "buy" | "sell"
  time: string
}

type WebSocketMessage = {
  type: "market" | "orderbook" | "trade" | "error"
  data: MarketData | OrderBookUpdate | TradeUpdate | { message: string }
}

// In a real app, this would be an actual WebSocket connection
class MarketDataService {
  private callbacks: Map<string, Set<(data: any) => void>> = new Map()
  private subscriptions: Set<string> = new Set()
  private interval: NodeJS.Timeout | null = null
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectDelay = 1000
  private connected = false

  private baselinePrices: Record<string, number> = {
    BTC: 68432.12,
    ETH: 3845.67,
    AAPL: 173.45,
    MSFT: 328.79,
    GOOGL: 142.56,
    AMZN: 178.23,
    SOL: 142.34,
    ADA: 0.58,
  }

  constructor() {
    this.connect()
  }

  private connect() {
    if (this.connected) return

    console.log("Connecting to market data stream...")

    // In a real app, you would connect to a WebSocket here
    // const socket = new WebSocket('wss://your-spring-boot-backend/market-stream')
    // socket.onmessage = this.handleMessage
    // socket.onclose = this.handleDisconnect

    // For demo purposes, we'll simulate WebSocket messages with an interval
    this.interval = setInterval(() => this.simulateMessages(), 2000)
    this.connected = true
    this.reconnectAttempts = 0
  }

  private handleDisconnect = () => {
    this.connected = false

    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++
      console.log(
        `WebSocket disconnected. Attempting to reconnect (${this.reconnectAttempts}/${this.maxReconnectAttempts})...`,
      )
      setTimeout(() => this.connect(), this.reconnectDelay * this.reconnectAttempts)
    } else {
      console.error("Maximum reconnection attempts reached. Please refresh the page.")
    }
  }

  private handleMessage = (event: MessageEvent) => {
    try {
      const message: WebSocketMessage = JSON.parse(event.data)
      this.dispatchMessage(message)
    } catch (error) {
      console.error("Error parsing WebSocket message:", error)
    }
  }

  private dispatchMessage(message: WebSocketMessage) {
    const { type, data } = message

    if (type === "error") {
      console.error("WebSocket error:", (data as { message: string }).message)
      return
    }

    const callbacks = this.callbacks.get(type)
    if (callbacks) {
      callbacks.forEach((callback) => callback(data))
    }
  }

  private simulateMessages() {
    // Only simulate messages for subscribed symbols
    if (this.subscriptions.size === 0) return

    const symbols = Array.from(this.subscriptions)
    const symbol = symbols[Math.floor(Math.random() * symbols.length)]
    const basePrice = this.baselinePrices[symbol]

    if (!basePrice) return

    // Generate a small price change
    const priceChange = (Math.random() * 0.01 - 0.005) * basePrice
    const newPrice = basePrice + priceChange

    // Calculate percent change (simulated)
    const percentChange = (priceChange / basePrice) * 100

    // Update the baseline price for next time
    this.baselinePrices[symbol] = newPrice

    // Simulate market data update
    this.dispatchMessage({
      type: "market",
      data: {
        symbol,
        price: newPrice,
        change: percentChange,
      },
    })

    // Simulate order book update (less frequently)
    if (Math.random() > 0.7) {
      const asks: Array<[number, number]> = []
      const bids: Array<[number, number]> = []

      for (let i = 0; i < 5; i++) {
        asks.push([newPrice + (i + 1) * (newPrice * 0.0005), Math.random() * 5 + 0.1])
        bids.push([newPrice - (i + 1) * (newPrice * 0.0005), Math.random() * 5 + 0.1])
      }

      this.dispatchMessage({
        type: "orderbook",
        data: {
          symbol,
          asks,
          bids,
        },
      })
    }

    // Simulate trade update (less frequently)
    if (Math.random() > 0.8) {
      this.dispatchMessage({
        type: "trade",
        data: {
          id: `trade-${Date.now()}`,
          symbol,
          price: newPrice,
          amount: Math.random() * 2,
          side: Math.random() > 0.5 ? "buy" : "sell",
          time: new Date().toISOString(),
        },
      })
    }
  }

  subscribe(symbol: string) {
    this.subscriptions.add(symbol)
    // In a real app, you would send a subscription message to the WebSocket
    // socket.send(JSON.stringify({ type: 'subscribe', symbol }))
  }

  unsubscribe(symbol: string) {
    this.subscriptions.delete(symbol)
    // In a real app, you would send an unsubscription message to the WebSocket
    // socket.send(JSON.stringify({ type: 'unsubscribe', symbol }))
  }

  on<T>(type: string, callback: (data: T) => void) {
    if (!this.callbacks.has(type)) {
      this.callbacks.set(type, new Set())
    }

    this.callbacks.get(type)!.add(callback)
  }

  off<T>(type: string, callback: (data: T) => void) {
    const callbacks = this.callbacks.get(type)
    if (callbacks) {
      callbacks.delete(callback)
    }
  }

  disconnect() {
    console.log("Disconnecting from market data stream...")

    if (this.interval) {
      clearInterval(this.interval)
      this.interval = null
    }

    this.connected = false
    this.subscriptions.clear()
    this.callbacks.clear()

    // In a real app, you would close the WebSocket
    // socket.close()
  }
}

// Singleton instance
const marketDataService = new MarketDataService()

export function connectToMarketStream(onMessage: (data: MarketData) => void) {
  marketDataService.on<MarketData>("market", onMessage)

  return {
    disconnect: () => {
      marketDataService.off("market", onMessage)
    },
  }
}

export function connectToOrderBookStream(symbol: string, onUpdate: (data: OrderBookUpdate) => void) {
  marketDataService.subscribe(symbol)
  marketDataService.on<OrderBookUpdate>("orderbook", onUpdate)

  return {
    disconnect: () => {
      marketDataService.unsubscribe(symbol)
      marketDataService.off("orderbook", onUpdate)
    },
  }
}

export function connectToTradeStream(symbol: string, onTrade: (data: TradeUpdate) => void) {
  marketDataService.subscribe(symbol)
  marketDataService.on<TradeUpdate>("trade", onTrade)

  return {
    disconnect: () => {
      marketDataService.unsubscribe(symbol)
      marketDataService.off("trade", onTrade)
    },
  }
}

export { marketDataService }

