export type OrderType = "market" | "limit"
export type OrderSide = "buy" | "sell"

export type Order = {
  id: string
  symbol: string
  type: OrderType
  side: OrderSide
  amount: number
  price: number
  total: number
  status: "pending" | "filled" | "canceled"
  createdAt: string
  updatedAt: string
}

export type OrderParams = {
  symbol: string
  type: OrderType
  side: OrderSide
  amount: number
  price?: number
}

class TradingService {
  private orders: Order[] = []

  constructor() {
    // Only access localStorage on the client side
    if (typeof window !== "undefined") {
      // Load orders from localStorage if available
      const storedOrders = localStorage.getItem("orders")
      if (storedOrders) {
        this.orders = JSON.parse(storedOrders)
      }
    }
  }

  private saveOrders() {
    // Only access localStorage on the client side
    if (typeof window !== "undefined") {
      localStorage.setItem("orders", JSON.stringify(this.orders))
    }
  }

  async placeOrder(params: OrderParams): Promise<Order> {
    // In a real app, this would be an API call to your backend
    // const response = await fetch('/api/orders', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(params),
    // })
    // const data = await response.json()

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const now = new Date().toISOString()
    const price = params.price || this.getCurrentPrice(params.symbol)

    const order: Order = {
      id: `order-${Date.now()}`,
      symbol: params.symbol,
      type: params.type,
      side: params.side,
      amount: params.amount,
      price,
      total: params.amount * price,
      status: "pending",
      createdAt: now,
      updatedAt: now,
    }

    // For demo purposes, we'll automatically fill market orders
    if (params.type === "market") {
      order.status = "filled"
    }

    this.orders.unshift(order)
    this.saveOrders()

    return order
  }

  async cancelOrder(orderId: string): Promise<Order> {
    // In a real app, this would be an API call to your backend
    // const response = await fetch(`/api/orders/${orderId}/cancel`, {
    //   method: 'POST'
    // })
    // const data = await response.json()

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    const orderIndex = this.orders.findIndex((order) => order.id === orderId)
    if (orderIndex === -1) {
      throw new Error("Order not found")
    }

    const order = this.orders[orderIndex]
    if (order.status === "filled") {
      throw new Error("Cannot cancel filled order")
    }

    order.status = "canceled"
    order.updatedAt = new Date().toISOString()

    this.orders[orderIndex] = order
    this.saveOrders()

    return order
  }

  getOrders(): Order[] {
    return this.orders
  }

  private getCurrentPrice(symbol: string): number {
    // In a real app, you would get the current price from your market data service
    const baselinePrices: Record<string, number> = {
      BTC: 68432.12,
      ETH: 3845.67,
      AAPL: 173.45,
      MSFT: 328.79,
      GOOGL: 142.56,
      AMZN: 178.23,
      SOL: 142.34,
      ADA: 0.58,
    }

    return baselinePrices[symbol] || 0
  }
}

// Singleton instance
export const tradingService = new TradingService()

