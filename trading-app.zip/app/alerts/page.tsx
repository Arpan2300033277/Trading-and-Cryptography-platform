"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"
import { useNotification } from "@/components/notification-system"
import { Bell, Check, Plus, Trash } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { connectToMarketStream } from "@/lib/websocket-client"

type PriceAlert = {
  id: string
  symbol: string
  price: number
  direction: "above" | "below"
  status: "active" | "triggered"
  createdAt: string
  triggeredAt?: string
}

export default function AlertsPage() {
  const [alerts, setAlerts] = useState<PriceAlert[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [newAlert, setNewAlert] = useState({
    symbol: "BTC",
    price: "",
    direction: "above" as const,
  })
  const [currentPrices, setCurrentPrices] = useState<Record<string, number>>({
    BTC: 68432.12,
    ETH: 3845.67,
    AAPL: 173.45,
    MSFT: 328.79,
  })
  const { isAuthenticated, isLoading: authLoading } = useAuth()
  const { addNotification } = useNotification()
  const router = useRouter()

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [authLoading, isAuthenticated, router])

  useEffect(() => {
    // Initialize sample alerts
    const sampleAlerts: PriceAlert[] = [
      {
        id: "alert-1",
        symbol: "BTC",
        price: 70000,
        direction: "above",
        status: "active",
        createdAt: "2023-03-15T10:30:00Z",
      },
      {
        id: "alert-2",
        symbol: "ETH",
        price: 3500,
        direction: "below",
        status: "triggered",
        createdAt: "2023-04-20T14:45:00Z",
        triggeredAt: "2023-04-21T09:15:00Z",
      },
      {
        id: "alert-3",
        symbol: "AAPL",
        price: 180,
        direction: "above",
        status: "active",
        createdAt: "2023-05-10T09:15:00Z",
      },
    ]

    setAlerts(sampleAlerts)
    setIsLoading(false)
  }, [])

  useEffect(() => {
    const { disconnect } = connectToMarketStream((data) => {
      setCurrentPrices((prev) => ({
        ...prev,
        [data.symbol]: data.price,
      }))

      // Check if any alerts should be triggered
      setAlerts((prev) => {
        let triggered = false

        const updatedAlerts = prev.map((alert) => {
          if (alert.status === "active" && alert.symbol === data.symbol) {
            if (
              (alert.direction === "above" && data.price >= alert.price) ||
              (alert.direction === "below" && data.price <= alert.price)
            ) {
              triggered = true

              return {
                ...alert,
                status: "triggered",
                triggeredAt: new Date().toISOString(),
              }
            }
          }

          return alert
        })

        if (triggered) {
          addNotification({
            type: "info",
            message: `Price alert triggered for ${data.symbol}!`,
            duration: 0,
          })
        }

        return updatedAlerts
      })
    })

    return () => {
      disconnect()
    }
  }, [addNotification])

  const handleCreateAlert = () => {
    if (!newAlert.price || isNaN(Number(newAlert.price)) || Number(newAlert.price) <= 0) {
      addNotification({
        type: "error",
        message: "Please enter a valid price",
      })
      return
    }

    const alert: PriceAlert = {
      id: `alert-${Date.now()}`,
      symbol: newAlert.symbol,
      price: Number(newAlert.price),
      direction: newAlert.direction,
      status: "active",
      createdAt: new Date().toISOString(),
    }

    setAlerts((prev) => [alert, ...prev])

    addNotification({
      type: "success",
      message: `Price alert created for ${newAlert.symbol}`,
    })

    // Reset form
    setNewAlert({
      symbol: "BTC",
      price: "",
      direction: "above",
    })

    setIsCreating(false)
  }

  const handleDeleteAlert = (id: string) => {
    setAlerts((prev) => prev.filter((alert) => alert.id !== id))

    addNotification({
      type: "success",
      message: "Price alert deleted",
    })
  }

  const handleToggleAlert = (id: string) => {
    setAlerts((prev) =>
      prev.map((alert) => {
        if (alert.id === id) {
          const newStatus = alert.status === "active" ? "triggered" : "active"

          return {
            ...alert,
            status: newStatus,
            triggeredAt: newStatus === "triggered" ? new Date().toISOString() : undefined,
          }
        }

        return alert
      }),
    )
  }

  if (authLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Price Alerts</h1>

        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Alert
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Price Alert</DialogTitle>
              <DialogDescription>
                Set up alerts to be notified when a price reaches a specific threshold.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="symbol">Asset</Label>
                <Select
                  value={newAlert.symbol}
                  onValueChange={(value) => setNewAlert((prev) => ({ ...prev, symbol: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select asset" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                    <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                    <SelectItem value="AAPL">Apple Inc. (AAPL)</SelectItem>
                    <SelectItem value="MSFT">Microsoft Corp. (MSFT)</SelectItem>
                  </SelectContent>
                </Select>
                <div className="text-sm text-muted-foreground">
                  Current price: $
                  {currentPrices[newAlert.symbol]?.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="direction">Alert Condition</Label>
                <RadioGroup
                  value={newAlert.direction}
                  onValueChange={(value: "above" | "below") => setNewAlert((prev) => ({ ...prev, direction: value }))}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="above" id="above" />
                    <Label htmlFor="above">Price goes above</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="below" id="below" />
                    <Label htmlFor="below">Price goes below</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Price Threshold</Label>
                <Input
                  id="price"
                  type="number"
                  placeholder="Enter price"
                  value={newAlert.price}
                  onChange={(e) => setNewAlert((prev) => ({ ...prev, price: e.target.value }))}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreating(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateAlert}>Create Alert</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : alerts.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <Bell className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-medium">No Price Alerts</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Create your first price alert to get notified when prices reach your targets.
            </p>
            <Button className="mt-6" onClick={() => setIsCreating(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Alert
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {alerts.map((alert) => (
            <Card key={alert.id} className={alert.status === "triggered" ? "bg-muted/50" : ""}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                      <Bell className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{alert.symbol}</h3>
                        <Badge variant={alert.status === "active" ? "default" : "secondary"}>
                          {alert.status === "active" ? "Active" : "Triggered"}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Alert when price goes {alert.direction} $
                        {alert.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </p>
                      {alert.status === "triggered" && alert.triggeredAt && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Triggered on {new Date(alert.triggeredAt).toLocaleString()}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {alert.status === "active" && (
                      <div className="flex items-center space-x-2 mr-4">
                        <Switch
                          id={`alert-status-${alert.id}`}
                          checked={alert.status === "active"}
                          onCheckedChange={() => handleToggleAlert(alert.id)}
                        />
                        <Label htmlFor={`alert-status-${alert.id}`}>Active</Label>
                      </div>
                    )}

                    <Button variant="ghost" size="icon" onClick={() => handleDeleteAlert(alert.id)}>
                      <Trash className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <div className="text-sm">
                    <span className="text-muted-foreground">Current price: </span>
                    <span className="font-medium">
                      $
                      {currentPrices[alert.symbol]?.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                    </span>
                  </div>

                  <div className="text-sm">
                    <span className="text-muted-foreground">Distance: </span>
                    <span
                      className={`font-medium ${
                        alert.direction === "above"
                          ? currentPrices[alert.symbol] < alert.price
                            ? "text-yellow-500"
                            : "text-green-500"
                          : currentPrices[alert.symbol] > alert.price
                            ? "text-yellow-500"
                            : "text-green-500"
                      }`}
                    >
                      {alert.direction === "above" ? (
                        currentPrices[alert.symbol] < alert.price ? (
                          `${(((alert.price - currentPrices[alert.symbol]) / currentPrices[alert.symbol]) * 100).toFixed(2)}% to go`
                        ) : (
                          <Check className="inline h-4 w-4" />
                        )
                      ) : currentPrices[alert.symbol] > alert.price ? (
                        `${(((currentPrices[alert.symbol] - alert.price) / alert.price) * 100).toFixed(2)}% to go`
                      ) : (
                        <Check className="inline h-4 w-4" />
                      )}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

