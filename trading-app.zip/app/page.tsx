"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MarketOverview } from "@/components/market-overview"
import { TradingView } from "@/components/trading-view"
import { WatchList } from "@/components/watch-list"
import { Portfolio } from "@/components/portfolio"
import { OrderBook } from "@/components/order-book"
import { RecentTrades } from "@/components/recent-trades"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowDown, ArrowUp, BarChart3, Bell, Briefcase, DollarSign, Sparkles, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"

export default function Home() {
  const { user, isAuthenticated, isLoading } = useAuth()
  const router = useRouter()
  const [portfolioValue, setPortfolioValue] = useState(0)
  const [portfolioChange, setPortfolioChange] = useState(0)
  const [portfolioChangePercent, setPortfolioChangePercent] = useState(0)
  const [activeAlerts, setActiveAlerts] = useState(2)
  const [activeBots, setActiveBots] = useState(2)
  const [isMarketOpen, setIsMarketOpen] = useState(true)

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [isLoading, isAuthenticated, router])

  useEffect(() => {
    if (user) {
      // Calculate portfolio value
      const btcValue = user.balance.BTC * 68432.12
      const ethValue = user.balance.ETH * 3845.67
      const aaplValue = 5 * 173.45 // Sample stock

      const total = btcValue + ethValue + aaplValue
      setPortfolioValue(total)

      // Calculate portfolio change
      const yesterdayValue = total * 0.98 // Simulated previous value
      const change = total - yesterdayValue
      const changePercent = (change / yesterdayValue) * 100

      setPortfolioChange(change)
      setPortfolioChangePercent(changePercent)
    }
  }, [user])

  // Check if market is open based on current time
  useEffect(() => {
    const checkMarketStatus = () => {
      const now = new Date()
      const day = now.getDay()
      const hours = now.getHours()

      // Simplified market hours: Monday-Friday, 9:30 AM - 4:00 PM
      // In reality, different markets have different hours
      if (day >= 1 && day <= 5 && hours >= 9 && hours < 16) {
        setIsMarketOpen(true)
      } else {
        setIsMarketOpen(false)
      }
    }

    checkMarketStatus()
    const interval = setInterval(checkMarketStatus, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [])

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Welcome back, {user?.name}</p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant={isMarketOpen ? "default" : "outline"} className="py-1">
            <span
              className={`mr-1.5 h-2 w-2 rounded-full ${isMarketOpen ? "bg-success animate-pulse" : "bg-muted-foreground"}`}
            ></span>
            {isMarketOpen ? "Market Open" : "Market Closed"}
          </Badge>
          <Button variant="outline" size="sm" asChild>
            <Link href="/analytics">
              <TrendingUp className="mr-2 h-4 w-4" />
              Analytics
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="card-hover-effect">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Portfolio Value</CardTitle>
            <Briefcase className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${portfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div
              className={`flex items-center text-xs ${portfolioChangePercent >= 0 ? "text-success" : "text-destructive"}`}
            >
              {portfolioChangePercent >= 0 ? (
                <ArrowUp className="mr-1 h-3 w-3" />
              ) : (
                <ArrowDown className="mr-1 h-3 w-3" />
              )}
              ${Math.abs(portfolioChange).toFixed(2)} ({Math.abs(portfolioChangePercent).toFixed(2)}%)
            </div>
            <Button variant="link" className="px-0 h-auto mt-2" asChild>
              <Link href="/portfolio">View Portfolio</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="card-hover-effect">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Available Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${user?.balance.USD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">Available for trading</p>
            <Button variant="link" className="px-0 h-auto mt-2" asChild>
              <Link href="/payments">Manage Funds</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="card-hover-effect">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Bots</CardTitle>
            <BarChart3 className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeBots}</div>
            <p className="text-xs text-muted-foreground">Trading automatically</p>
            <Button variant="link" className="px-0 h-auto mt-2" asChild>
              <Link href="/bots">Manage Bots</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="card-hover-effect">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Price Alerts</CardTitle>
            <Bell className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeAlerts}</div>
            <p className="text-xs text-muted-foreground">Active price notifications</p>
            <Button variant="link" className="px-0 h-auto mt-2" asChild>
              <Link href="/alerts">Manage Alerts</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="relative">
        <div className="absolute -top-1 -left-1 w-20 h-20 bg-primary/20 rounded-full blur-xl"></div>
        <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-secondary/20 rounded-full blur-xl"></div>
        <MarketOverview />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-6">
          <Tabs defaultValue="chart">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="chart">Chart</TabsTrigger>
              <TabsTrigger value="orderbook">Order Book</TabsTrigger>
            </TabsList>
            <TabsContent value="chart" className="space-y-4">
              <TradingView />
            </TabsContent>
            <TabsContent value="orderbook" className="space-y-4">
              <OrderBook />
            </TabsContent>
          </Tabs>
          <RecentTrades />
        </div>
        <div className="space-y-6">
          <WatchList />
          <Portfolio />
        </div>
      </div>

      <div className="mt-8 p-6 rounded-lg glass-effect relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/10 rounded-full blur-xl"></div>
        <h2 className="text-xl font-bold mb-3 flex items-center">
          <Sparkles className="mr-2 h-5 w-5 text-primary" />
          Pro Trading Tips
        </h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <h3 className="font-medium">Risk Management</h3>
            <p className="text-sm text-muted-foreground">
              Never risk more than 1-2% of your portfolio on a single trade. Set stop losses to protect your capital.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-medium">Technical Analysis</h3>
            <p className="text-sm text-muted-foreground">
              Use multiple timeframes to confirm trends. Look for confluence between different indicators.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

