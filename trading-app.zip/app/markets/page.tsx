"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/lib/auth-context"
import { ArrowDown, ArrowUp, Search, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { connectToMarketStream } from "@/lib/websocket-client"
import { useNotification } from "@/components/notification-system"

type MarketData = {
  symbol: string
  name: string
  price: number
  change: number
  volume: string
  marketCap: string
  type: "stock" | "crypto"
  isFavorite: boolean
}

export default function MarketsPage() {
  const [marketData, setMarketData] = useState<MarketData[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const { isAuthenticated, isLoading: authLoading } = useAuth()
  const { addNotification } = useNotification()
  const router = useRouter()

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [authLoading, isAuthenticated, router])

  useEffect(() => {
    // Initialize market data
    const initialData: MarketData[] = [
      {
        symbol: "BTC",
        name: "Bitcoin",
        price: 68432.12,
        change: 2.34,
        volume: "32.1B",
        marketCap: "1.34T",
        type: "crypto",
        isFavorite: true,
      },
      {
        symbol: "ETH",
        name: "Ethereum",
        price: 3845.67,
        change: 1.78,
        volume: "18.7B",
        marketCap: "462.3B",
        type: "crypto",
        isFavorite: true,
      },
      {
        symbol: "SOL",
        name: "Solana",
        price: 142.34,
        change: 5.67,
        volume: "5.2B",
        marketCap: "61.5B",
        type: "crypto",
        isFavorite: false,
      },
      {
        symbol: "ADA",
        name: "Cardano",
        price: 0.58,
        change: -1.23,
        volume: "1.8B",
        marketCap: "20.7B",
        type: "crypto",
        isFavorite: false,
      },
      {
        symbol: "DOT",
        name: "Polkadot",
        price: 7.82,
        change: 0.45,
        volume: "890M",
        marketCap: "10.2B",
        type: "crypto",
        isFavorite: false,
      },
      {
        symbol: "LINK",
        name: "Chainlink",
        price: 15.67,
        change: 3.21,
        volume: "750M",
        marketCap: "9.1B",
        type: "crypto",
        isFavorite: false,
      },
      {
        symbol: "AAPL",
        name: "Apple Inc.",
        price: 173.45,
        change: 1.23,
        volume: "52.3M",
        marketCap: "2.73T",
        type: "stock",
        isFavorite: true,
      },
      {
        symbol: "MSFT",
        name: "Microsoft Corp.",
        price: 328.79,
        change: 2.56,
        volume: "23.1M",
        marketCap: "2.45T",
        type: "stock",
        isFavorite: false,
      },
      {
        symbol: "GOOGL",
        name: "Alphabet Inc.",
        price: 142.56,
        change: -0.87,
        volume: "18.7M",
        marketCap: "1.82T",
        type: "stock",
        isFavorite: false,
      },
      {
        symbol: "AMZN",
        name: "Amazon.com Inc.",
        price: 178.23,
        change: 1.45,
        volume: "31.2M",
        marketCap: "1.85T",
        type: "stock",
        isFavorite: false,
      },
      {
        symbol: "TSLA",
        name: "Tesla Inc.",
        price: 175.34,
        change: -2.12,
        volume: "28.5M",
        marketCap: "557B",
        type: "stock",
        isFavorite: false,
      },
      {
        symbol: "META",
        name: "Meta Platforms Inc.",
        price: 485.92,
        change: 1.78,
        volume: "15.3M",
        marketCap: "1.24T",
        type: "stock",
        isFavorite: false,
      },
    ]

    setMarketData(initialData)
    setIsLoading(false)
  }, [])

  useEffect(() => {
    const { disconnect } = connectToMarketStream((data) => {
      setMarketData((prevData) => {
        return prevData.map((item) => {
          if (item.symbol === data.symbol) {
            return {
              ...item,
              price: data.price,
              change: data.change,
            }
          }
          return item
        })
      })
    })

    return () => {
      disconnect()
    }
  }, [])

  const toggleFavorite = (symbol: string) => {
    setMarketData((prevData) => {
      return prevData.map((item) => {
        if (item.symbol === symbol) {
          const newState = !item.isFavorite

          // Show notification
          addNotification({
            type: "success",
            message: newState ? `Added ${symbol} to favorites` : `Removed ${symbol} from favorites`,
          })

          return {
            ...item,
            isFavorite: newState,
          }
        }
        return item
      })
    })
  }

  const filteredMarketData = marketData.filter((item) => {
    if (!searchQuery) return true

    const query = searchQuery.toLowerCase()
    return item.symbol.toLowerCase().includes(query) || item.name.toLowerCase().includes(query)
  })

  if (authLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Markets</h1>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search markets..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Market Overview</CardTitle>
          <CardDescription>Real-time market data for stocks and cryptocurrencies</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="favorites">Favorites</TabsTrigger>
              <TabsTrigger value="crypto">Crypto</TabsTrigger>
              <TabsTrigger value="stocks">Stocks</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-4">
              <MarketTable data={filteredMarketData} toggleFavorite={toggleFavorite} />
            </TabsContent>
            <TabsContent value="favorites" className="mt-4">
              <MarketTable
                data={filteredMarketData.filter((item) => item.isFavorite)}
                toggleFavorite={toggleFavorite}
              />
            </TabsContent>
            <TabsContent value="crypto" className="mt-4">
              <MarketTable
                data={filteredMarketData.filter((item) => item.type === "crypto")}
                toggleFavorite={toggleFavorite}
              />
            </TabsContent>
            <TabsContent value="stocks" className="mt-4">
              <MarketTable
                data={filteredMarketData.filter((item) => item.type === "stock")}
                toggleFavorite={toggleFavorite}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

function MarketTable({
  data,
  toggleFavorite,
}: {
  data: MarketData[]
  toggleFavorite: (symbol: string) => void
}) {
  const router = useRouter()

  const handleRowClick = (symbol: string) => {
    router.push(`/trade/${symbol}`)
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b text-left">
            <th className="pb-2 font-medium w-10"></th>
            <th className="pb-2 font-medium">Symbol</th>
            <th className="pb-2 font-medium">Name</th>
            <th className="pb-2 font-medium text-right">Price</th>
            <th className="pb-2 font-medium text-right">24h Change</th>
            <th className="pb-2 font-medium text-right hidden md:table-cell">Volume</th>
            <th className="pb-2 font-medium text-right hidden md:table-cell">Market Cap</th>
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={7} className="py-4 text-center text-muted-foreground">
                No markets found
              </td>
            </tr>
          ) : (
            data.map((item) => (
              <tr
                key={item.symbol}
                className="border-b last:border-0 hover:bg-muted/50 cursor-pointer"
                onClick={() => handleRowClick(item.symbol)}
              >
                <td className="py-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-8 w-8 ${item.isFavorite ? "text-yellow-500" : "text-muted-foreground"}`}
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleFavorite(item.symbol)
                    }}
                  >
                    <Star className="h-4 w-4" fill={item.isFavorite ? "currentColor" : "none"} />
                    <span className="sr-only">{item.isFavorite ? "Remove from favorites" : "Add to favorites"}</span>
                  </Button>
                </td>
                <td className="py-3 font-medium">{item.symbol}</td>
                <td className="py-3 text-muted-foreground">{item.name}</td>
                <td className="py-3 text-right font-medium">
                  {item.type === "crypto" ? "$" : "$"}
                  {item.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className={`py-3 text-right ${item.change >= 0 ? "text-green-500" : "text-red-500"}`}>
                  <span className="flex items-center justify-end">
                    {item.change >= 0 ? <ArrowUp className="mr-1 h-4 w-4" /> : <ArrowDown className="mr-1 h-4 w-4" />}
                    {Math.abs(item.change).toFixed(2)}%
                  </span>
                </td>
                <td className="py-3 text-right text-muted-foreground hidden md:table-cell">{item.volume}</td>
                <td className="py-3 text-right text-muted-foreground hidden md:table-cell">{item.marketCap}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}

