"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/lib/auth-context"
import { ArrowDown, ArrowUp, BarChart3, Calendar, CreditCard, DollarSign, Download, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart as RechartsPieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { tradingService } from "@/lib/trading-service"

// Types
type TimeRange = "1w" | "1m" | "3m" | "6m" | "1y" | "all"
type AssetPerformance = {
  symbol: string
  name: string
  value: number
  profit: number
  profitPercent: number
  color: string
}
type TradeStats = {
  totalTrades: number
  winningTrades: number
  losingTrades: number
  winRate: number
  avgProfit: number
  avgLoss: number
  profitFactor: number
  largestWin: number
  largestLoss: number
}
type DailyPerformance = {
  date: string
  profit: number
  trades: number
}
type TradeDistribution = {
  name: string
  value: number
  color: string
}

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState<TimeRange>("1m")
  const [isLoading, setIsLoading] = useState(true)
  const [portfolioValue, setPortfolioValue] = useState(0)
  const [portfolioChange, setPortfolioChange] = useState(0)
  const [portfolioChangePercent, setPortfolioChangePercent] = useState(0)
  const [assetPerformance, setAssetPerformance] = useState<AssetPerformance[]>([])
  const [tradeStats, setTradeStats] = useState<TradeStats>({
    totalTrades: 0,
    winningTrades: 0,
    losingTrades: 0,
    winRate: 0,
    avgProfit: 0,
    avgLoss: 0,
    profitFactor: 0,
    largestWin: 0,
    largestLoss: 0,
  })
  const [dailyPerformance, setDailyPerformance] = useState<DailyPerformance[]>([])
  const [tradeDistribution, setTradeDistribution] = useState<TradeDistribution[]>([])
  const [portfolioHistory, setPortfolioHistory] = useState<{ date: string; value: number }[]>([])

  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [authLoading, isAuthenticated, router])

  useEffect(() => {
    if (!isAuthenticated) return

    const loadAnalyticsData = async () => {
      setIsLoading(true)

      try {
        // In a real app, this would be API calls to get analytics data
        // For demo purposes, we'll generate sample data

        // Get orders from trading service
        const orders = tradingService.getOrders()

        // Calculate portfolio value and change
        const btcValue = (user?.balance.BTC || 0) * 68432.12
        const ethValue = (user?.balance.ETH || 0) * 3845.67
        const aaplValue = 5 * 173.45 // Sample stock

        const total = btcValue + ethValue + aaplValue
        setPortfolioValue(total)

        // Calculate portfolio change based on time range
        const changeFactors: Record<TimeRange, number> = {
          "1w": 0.98,
          "1m": 0.95,
          "3m": 0.9,
          "6m": 0.85,
          "1y": 0.75,
          all: 0.5,
        }

        const previousValue = total * changeFactors[timeRange]
        const change = total - previousValue
        const changePercent = (change / previousValue) * 100

        setPortfolioChange(change)
        setPortfolioChangePercent(changePercent)

        // Generate asset performance data
        setAssetPerformance([
          {
            symbol: "BTC",
            name: "Bitcoin",
            value: btcValue,
            profit: btcValue * 0.05,
            profitPercent: 5.0,
            color: "#F7931A",
          },
          {
            symbol: "ETH",
            name: "Ethereum",
            value: ethValue,
            profit: ethValue * 0.03,
            profitPercent: 3.0,
            color: "#627EEA",
          },
          {
            symbol: "AAPL",
            name: "Apple Inc.",
            value: aaplValue,
            profit: aaplValue * -0.01,
            profitPercent: -1.0,
            color: "#A2AAAD",
          },
        ])

        // Generate trade statistics
        const totalTrades = orders.length
        const winningTrades = orders.filter(
          (o) => (o.side === "buy" && o.price < 68432.12) || (o.side === "sell" && o.price > 68432.12),
        ).length
        const losingTrades = totalTrades - winningTrades

        setTradeStats({
          totalTrades,
          winningTrades,
          losingTrades,
          winRate: totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0,
          avgProfit: 120.5,
          avgLoss: 75.25,
          profitFactor: 1.6,
          largestWin: 450.75,
          largestLoss: 210.3,
        })

        // Generate daily performance data
        const days =
          timeRange === "1w"
            ? 7
            : timeRange === "1m"
              ? 30
              : timeRange === "3m"
                ? 90
                : timeRange === "6m"
                  ? 180
                  : timeRange === "1y"
                    ? 365
                    : 500

        const dailyData: DailyPerformance[] = []
        const now = new Date()

        for (let i = days - 1; i >= 0; i--) {
          const date = new Date(now)
          date.setDate(date.getDate() - i)

          // Generate random profit and trades
          const profit = Math.random() * 200 - 100
          const trades = Math.floor(Math.random() * 5)

          dailyData.push({
            date: date.toISOString().split("T")[0],
            profit,
            trades,
          })
        }

        setDailyPerformance(dailyData)

        // Generate trade distribution data
        setTradeDistribution([
          { name: "BTC", value: 45, color: "#F7931A" },
          { name: "ETH", value: 30, color: "#627EEA" },
          { name: "AAPL", value: 15, color: "#A2AAAD" },
          { name: "MSFT", value: 10, color: "#00A4EF" },
        ])

        // Generate portfolio history
        const historyData = []

        for (let i = days - 1; i >= 0; i--) {
          const date = new Date(now)
          date.setDate(date.getDate() - i)

          // Generate a value that trends toward the current value
          const randomFactor = 0.95 + Math.random() * 0.1
          const value = i === 0 ? total : total * (0.9 + (i / days) * 0.2) * randomFactor

          historyData.push({
            date: date.toISOString().split("T")[0],
            value,
          })
        }

        setPortfolioHistory(historyData)
      } catch (error) {
        console.error("Failed to load analytics data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadAnalyticsData()
  }, [isAuthenticated, timeRange, user])

  if (authLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Analytics</h1>

        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={(value: TimeRange) => setTimeRange(value)}>
            <SelectTrigger className="w-[180px]">
              <Calendar className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1w">Last Week</SelectItem>
              <SelectItem value="1m">Last Month</SelectItem>
              <SelectItem value="3m">Last 3 Months</SelectItem>
              <SelectItem value="6m">Last 6 Months</SelectItem>
              <SelectItem value="1y">Last Year</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : (
        <>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Portfolio Value</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  ${portfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div
                  className={`flex items-center text-xs ${portfolioChangePercent >= 0 ? "text-green-500" : "text-red-500"}`}
                >
                  {portfolioChangePercent >= 0 ? (
                    <ArrowUp className="mr-1 h-3 w-3" />
                  ) : (
                    <ArrowDown className="mr-1 h-3 w-3" />
                  )}
                  ${Math.abs(portfolioChange).toFixed(2)} ({Math.abs(portfolioChangePercent).toFixed(2)}%)
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Trades</CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{tradeStats.totalTrades}</div>
                <p className="text-xs text-muted-foreground">Win rate: {tradeStats.winRate.toFixed(1)}%</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{tradeStats.profitFactor.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">Avg. profit: ${tradeStats.avgProfit.toFixed(2)}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Best Performer</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {assetPerformance.length > 0
                    ? assetPerformance.sort((a, b) => b.profitPercent - a.profitPercent)[0].symbol
                    : "N/A"}
                </div>
                <div className="text-xs text-green-500">
                  {assetPerformance.length > 0
                    ? `+${assetPerformance.sort((a, b) => b.profitPercent - a.profitPercent)[0].profitPercent.toFixed(2)}%`
                    : "N/A"}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-2 mb-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Portfolio Performance</CardTitle>
                <CardDescription>Historical portfolio value over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ChartContainer
                    config={{
                      value: {
                        label: "Portfolio Value",
                        color: "hsl(var(--chart-1))",
                      },
                    }}
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={portfolioHistory}>
                        <defs>
                          <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.8} />
                            <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <XAxis
                          dataKey="date"
                          tickFormatter={(value) => {
                            const date = new Date(value)
                            return `${date.getMonth() + 1}/${date.getDate()}`
                          }}
                          tickMargin={10}
                        />
                        <YAxis tickFormatter={(value) => `$${value.toLocaleString()}`} width={80} />
                        <CartesianGrid strokeDasharray="3 3" />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Area
                          type="monotone"
                          dataKey="value"
                          name="Portfolio Value"
                          stroke="var(--color-value)"
                          fillOpacity={1}
                          fill="url(#colorValue)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="performance">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="assets">Assets</TabsTrigger>
              <TabsTrigger value="trades">Trades</TabsTrigger>
            </TabsList>

            <TabsContent value="performance" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Daily Performance</CardTitle>
                    <CardDescription>Profit/loss by day</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ChartContainer
                        config={{
                          profit: {
                            label: "Profit/Loss",
                            color: "hsl(var(--chart-1))",
                          },
                        }}
                      >
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={dailyPerformance.slice(-30)}>
                            <XAxis
                              dataKey="date"
                              tickFormatter={(value) => {
                                const date = new Date(value)
                                return `${date.getMonth() + 1}/${date.getDate()}`
                              }}
                              tickMargin={10}
                            />
                            <YAxis tickFormatter={(value) => `$${value}`} width={80} />
                            <ChartTooltip content={<ChartTooltipContent />} />
                            <Bar dataKey="profit" name="Profit/Loss" fill="var(--color-profit)">
                              {dailyPerformance.slice(-30).map((entry, index) => (
                                <Cell
                                  key={`cell-${index}`}
                                  fill={entry.profit >= 0 ? "hsl(var(--success))" : "hsl(var(--destructive))"}
                                />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </ChartContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Trade Statistics</CardTitle>
                    <CardDescription>Key performance metrics</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-sm font-medium text-muted-foreground">Win Rate</div>
                          <div className="text-2xl font-bold">{tradeStats.winRate.toFixed(1)}%</div>
                        </div>
                        <div>
                          <div className="text-sm font-medium text-muted-foreground">Profit Factor</div>
                          <div className="text-2xl font-bold">{tradeStats.profitFactor.toFixed(2)}</div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="grid grid-cols-2 gap-1">
                          <div className="text-sm font-medium text-muted-foreground">Total Trades</div>
                          <div>{tradeStats.totalTrades}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-1">
                          <div className="text-sm font-medium text-muted-foreground">Winning Trades</div>
                          <div className="text-green-500">{tradeStats.winningTrades}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-1">
                          <div className="text-sm font-medium text-muted-foreground">Losing Trades</div>
                          <div className="text-red-500">{tradeStats.losingTrades}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-1">
                          <div className="text-sm font-medium text-muted-foreground">Average Profit</div>
                          <div className="text-green-500">${tradeStats.avgProfit.toFixed(2)}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-1">
                          <div className="text-sm font-medium text-muted-foreground">Average Loss</div>
                          <div className="text-red-500">${tradeStats.avgLoss.toFixed(2)}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-1">
                          <div className="text-sm font-medium text-muted-foreground">Largest Win</div>
                          <div className="text-green-500">${tradeStats.largestWin.toFixed(2)}</div>
                        </div>
                        <div className="grid grid-cols-2 gap-1">
                          <div className="text-sm font-medium text-muted-foreground">Largest Loss</div>
                          <div className="text-red-500">${tradeStats.largestLoss.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="assets" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Asset Performance</CardTitle>
                    <CardDescription>Performance by asset</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {assetPerformance.map((asset) => (
                        <div key={asset.symbol} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: asset.color }}></div>
                              <div className="font-medium">{asset.symbol}</div>
                            </div>
                            <div className={`${asset.profitPercent >= 0 ? "text-green-500" : "text-red-500"}`}>
                              {asset.profitPercent >= 0 ? "+" : ""}
                              {asset.profitPercent.toFixed(2)}%
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="text-muted-foreground">{asset.name}</div>
                            <div>
                              $
                              {asset.value.toLocaleString(undefined, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                              })}
                            </div>
                          </div>
                          <div className="h-1 bg-muted overflow-hidden rounded-full">
                            <div
                              className={`h-full ${asset.profitPercent >= 0 ? "bg-green-500" : "bg-red-500"}`}
                              style={{ width: `${Math.min(Math.abs(asset.profitPercent) * 2, 100)}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Asset Allocation</CardTitle>
                    <CardDescription>Portfolio distribution</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={tradeDistribution}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            labelLine={false}
                          >
                            {tradeDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(value) => [`${value}%`, "Allocation"]}
                            contentStyle={{
                              backgroundColor: "hsl(var(--popover))",
                              borderColor: "hsl(var(--border))",
                              borderRadius: "var(--radius)",
                              color: "hsl(var(--popover-foreground))",
                            }}
                          />
                          <Legend />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="trades" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Trade History</CardTitle>
                  <CardDescription>Your recent trading activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b text-left">
                          <th className="pb-2 font-medium">Date</th>
                          <th className="pb-2 font-medium">Symbol</th>
                          <th className="pb-2 font-medium">Type</th>
                          <th className="pb-2 font-medium">Side</th>
                          <th className="pb-2 font-medium text-right">Amount</th>
                          <th className="pb-2 font-medium text-right">Price</th>
                          <th className="pb-2 font-medium text-right">Total</th>
                          <th className="pb-2 font-medium text-right">P/L</th>
                        </tr>
                      </thead>
                      <tbody>
                        {tradingService.getOrders().length === 0 ? (
                          <tr>
                            <td colSpan={8} className="py-4 text-center text-muted-foreground">
                              No trades found
                            </td>
                          </tr>
                        ) : (
                          tradingService.getOrders().map((order, index) => {
                            // Generate random P/L for demo purposes
                            const profitLoss =
                              order.side === "buy"
                                ? (68432.12 - order.price) * order.amount
                                : (order.price - 68432.12) * order.amount

                            return (
                              <tr key={order.id} className="border-b last:border-0">
                                <td className="py-3 text-sm">{new Date(order.createdAt).toLocaleString()}</td>
                                <td className="py-3 font-medium">{order.symbol}</td>
                                <td className="py-3">{order.type}</td>
                                <td className={`py-3 ${order.side === "buy" ? "text-green-500" : "text-red-500"}`}>
                                  {order.side}
                                </td>
                                <td className="py-3 text-right">{order.amount.toFixed(8)}</td>
                                <td className="py-3 text-right">${order.price.toFixed(2)}</td>
                                <td className="py-3 text-right">${order.total.toFixed(2)}</td>
                                <td
                                  className={`py-3 text-right ${profitLoss >= 0 ? "text-green-500" : "text-red-500"}`}
                                >
                                  {profitLoss >= 0 ? "+" : ""}${profitLoss.toFixed(2)}
                                </td>
                              </tr>
                            )
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}

