"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"
import { useNotification } from "@/components/notification-system"
import { tradingService, type Order } from "@/lib/trading-service"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { isAuthenticated, isLoading: authLoading } = useAuth()
  const { addNotification } = useNotification()
  const router = useRouter()

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [authLoading, isAuthenticated, router])

  useEffect(() => {
    if (isAuthenticated) {
      loadOrders()
    }
  }, [isAuthenticated])

  const loadOrders = () => {
    setIsLoading(true)
    try {
      const orders = tradingService.getOrders()
      setOrders(orders)
    } catch (error) {
      console.error("Failed to load orders:", error)
      addNotification({
        type: "error",
        message: "Failed to load orders",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleCancelOrder = async (orderId: string) => {
    try {
      await tradingService.cancelOrder(orderId)
      addNotification({
        type: "success",
        message: "Order cancelled successfully",
      })
      loadOrders()
    } catch (error) {
      console.error("Failed to cancel order:", error)
      addNotification({
        type: "error",
        message: "Failed to cancel order",
      })
    }
  }

  if (authLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-6">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="icon" asChild className="mr-2">
          <Link href="/">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Order History</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Orders</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2">Loading orders...</p>
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-4 text-muted-foreground">
              No orders found. Start trading to see your orders here.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left">
                    <th className="pb-2 font-medium">Date</th>
                    <th className="pb-2 font-medium">Symbol</th>
                    <th className="pb-2 font-medium">Type</th>
                    <th className="pb-2 font-medium">Side</th>
                    <th className="pb-2 font-medium text-right">Amount</th>
                    <th className="pb-2 font-medium text-right">Price</th>
                    <th className="pb-2 font-medium text-right">Total</th>
                    <th className="pb-2 font-medium text-center">Status</th>
                    <th className="pb-2 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.id} className="border-b last:border-0">
                      <td className="py-3 text-sm">{new Date(order.createdAt).toLocaleString()}</td>
                      <td className="py-3 font-medium">{order.symbol}</td>
                      <td className="py-3">{order.type}</td>
                      <td className={`py-3 ${order.side === "buy" ? "text-green-500" : "text-red-500"}`}>
                        {order.side}
                      </td>
                      <td className="py-3 text-right">{order.amount.toFixed(8)}</td>
                      <td className="py-3 text-right">${order.price.toFixed(2)}</td>
                      <td className="py-3 text-right">${order.total.toFixed(2)}</td>
                      <td className="py-3 text-center">
                        <span
                          className={`px-2 py-1 rounded-full text-xs ${
                            order.status === "filled"
                              ? "bg-green-100 text-green-800"
                              : order.status === "canceled"
                                ? "bg-gray-100 text-gray-800"
                                : "bg-blue-100 text-blue-800"
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        {order.status === "pending" && (
                          <Button variant="ghost" size="sm" onClick={() => handleCancelOrder(order.id)}>
                            Cancel
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

