"use client"

import { useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/lib/auth-context"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { TradingView } from "@/components/trading-view"
import { OrderBook } from "@/components/order-book"
import { RecentTrades } from "@/components/recent-trades"
import Link from "next/link"

export default function TradePage() {
  const params = useParams()
  const symbol = params.symbol as string
  const { isAuthenticated, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [isLoading, isAuthenticated, router])

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/markets">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">{symbol} Trading</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-6">
          <TradingView />

          <Tabs defaultValue="orderbook">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="orderbook">Order Book</TabsTrigger>
              <TabsTrigger value="trades">Recent Trades</TabsTrigger>
            </TabsList>
            <TabsContent value="orderbook" className="space-y-4">
              <OrderBook />
            </TabsContent>
            <TabsContent value="trades" className="space-y-4">
              <RecentTrades />
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Market Info</CardTitle>
              <CardDescription>Key statistics for {symbol}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">24h High</span>
                  <span className="font-medium">
                    $
                    {symbol === "BTC"
                      ? "69,245.00"
                      : symbol === "ETH"
                        ? "3,950.75"
                        : symbol === "AAPL"
                          ? "175.89"
                          : "335.45"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">24h Low</span>
                  <span className="font-medium">
                    $
                    {symbol === "BTC"
                      ? "67,120.50"
                      : symbol === "ETH"
                        ? "3,780.25"
                        : symbol === "AAPL"
                          ? "171.30"
                          : "325.60"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">24h Volume</span>
                  <span className="font-medium">
                    {symbol === "BTC"
                      ? "$32.1B"
                      : symbol === "ETH"
                        ? "$18.7B"
                        : symbol === "AAPL"
                          ? "$52.3M"
                          : "$23.1M"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Market Cap</span>
                  <span className="font-medium">
                    {symbol === "BTC"
                      ? "$1.34T"
                      : symbol === "ETH"
                        ? "$462.3B"
                        : symbol === "AAPL"
                          ? "$2.73T"
                          : "$2.45T"}
                  </span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t">
                <h4 className="font-medium mb-2">Quick Actions</h4>
                <div className="space-y-2">
                  <Button variant="outline" size="sm" className="w-full" asChild>
                    <Link href={`/alerts?symbol=${symbol}`}>Set Price Alert</Link>
                  </Button>
                  <Button variant="outline" size="sm" className="w-full" asChild>
                    <Link href={`/bots/new?symbol=${symbol}`}>Create Trading Bot</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

