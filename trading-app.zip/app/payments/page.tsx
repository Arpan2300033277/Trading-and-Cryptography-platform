"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"
import { useNotification } from "@/components/notification-system"
import {
  AlertCircle,
  ArrowDown,
  ArrowUp,
  Check,
  CreditCard,
  DollarSign,
  Download,
  Plus,
  RefreshCw,
  Trash,
  Wallet,
} from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Skeleton } from "@/components/ui/skeleton"

type PaymentMethod = {
  id: string
  type: "card" | "bank" | "crypto"
  name: string
  details: string
  isDefault: boolean
}

type Transaction = {
  id: string
  type: "deposit" | "withdrawal"
  amount: number
  method: string
  status: "pending" | "completed" | "failed"
  date: string
  fee: number
  currency: "USD" | "INR"
}

export default function PaymentsPage() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddingMethod, setIsAddingMethod] = useState(false)
  const [isDepositing, setIsDepositing] = useState(false)
  const [isWithdrawing, setIsWithdrawing] = useState(false)
  const [newMethod, setNewMethod] = useState({
    type: "card" as const,
    cardNumber: "",
    cardName: "",
    cardExpiry: "",
    cardCvc: "",
  })
  const [depositAmount, setDepositAmount] = useState("")
  const [depositMethod, setDepositMethod] = useState("")
  const [withdrawAmount, setWithdrawAmount] = useState("")
  const [withdrawMethod, setWithdrawMethod] = useState("")
  const [currency, setCurrency] = useState<"USD" | "INR">("USD")

  const { user, isAuthenticated, isLoading: authLoading, updateBalance } = useAuth()
  const { addNotification } = useNotification()
  const router = useRouter()

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [authLoading, isAuthenticated, router])

  useEffect(() => {
    if (!isAuthenticated) return

    // Load payment methods and transactions
    const loadPaymentData = async () => {
      setIsLoading(true)

      try {
        // In a real app, this would be API calls to get payment data
        // For demo purposes, we'll generate sample data

        // Sample payment methods
        const sampleMethods: PaymentMethod[] = [
          {
            id: "pm-1",
            type: "card",
            name: "Visa ending in 4242",
            details: "Expires 12/25",
            isDefault: true,
          },
          {
            id: "pm-2",
            type: "bank",
            name: "Chase Bank",
            details: "Account ending in 6789",
            isDefault: false,
          },
          {
            id: "pm-3",
            type: "crypto",
            name: "Bitcoin Wallet",
            details: "bc1q...7j4v",
            isDefault: false,
          },
          {
            id: "pm-4",
            type: "bank",
            name: "HDFC Bank",
            details: "Account ending in 3456",
            isDefault: false,
          },
          {
            id: "pm-5",
            type: "card",
            name: "RuPay ending in 8901",
            details: "Expires 09/26",
            isDefault: false,
          },
        ]

        // Sample transactions
        const sampleTransactions: Transaction[] = [
          {
            id: "tx-1",
            type: "deposit",
            amount: 5000,
            method: "Visa ending in 4242",
            status: "completed",
            date: "2023-03-15T10:30:00Z",
            fee: 0,
            currency: "USD",
          },
          {
            id: "tx-2",
            type: "withdrawal",
            amount: 1500,
            method: "Chase Bank",
            status: "completed",
            date: "2023-04-20T14:45:00Z",
            fee: 25,
            currency: "USD",
          },
          {
            id: "tx-3",
            type: "deposit",
            amount: 150000,
            method: "HDFC Bank",
            status: "completed",
            date: "2023-05-05T09:15:00Z",
            fee: 0,
            currency: "INR",
          },
          {
            id: "tx-4",
            type: "deposit",
            amount: 2000,
            method: "Bitcoin Wallet",
            status: "pending",
            date: "2023-05-10T09:15:00Z",
            fee: 10,
            currency: "USD",
          },
          {
            id: "tx-5",
            type: "withdrawal",
            amount: 75000,
            method: "RuPay ending in 8901",
            status: "completed",
            date: "2023-05-15T14:30:00Z",
            fee: 375,
            currency: "INR",
          },
        ]

        // Simulate network delay
        setTimeout(() => {
          setPaymentMethods(sampleMethods)
          setTransactions(sampleTransactions)
          setIsLoading(false)
        }, 1000)
      } catch (error) {
        console.error("Failed to load payment data:", error)
        setIsLoading(false)
        addNotification({
          type: "error",
          message: "Failed to load payment data. Please try again.",
        })
      }
    }

    loadPaymentData()
  }, [isAuthenticated, addNotification])

  const handleAddPaymentMethod = () => {
    if (newMethod.type === "card") {
      if (!newMethod.cardNumber || !newMethod.cardName || !newMethod.cardExpiry || !newMethod.cardCvc) {
        addNotification({
          type: "error",
          message: "Please fill in all card details",
        })
        return
      }

      // Validate card number (simple check for demo)
      if (newMethod.cardNumber.replace(/\s/g, "").length !== 16) {
        addNotification({
          type: "error",
          message: "Please enter a valid 16-digit card number",
        })
        return
      }
    }

    const method: PaymentMethod = {
      id: `pm-${Date.now()}`,
      type: newMethod.type,
      name:
        newMethod.type === "card"
          ? `Card ending in ${newMethod.cardNumber.slice(-4)}`
          : newMethod.type === "bank"
            ? "Bank Account"
            : "Crypto Wallet",
      details:
        newMethod.type === "card"
          ? `Expires ${newMethod.cardExpiry}`
          : newMethod.type === "bank"
            ? "Account details"
            : "Wallet address",
      isDefault: paymentMethods.length === 0,
    }

    setPaymentMethods((prev) => [...prev, method])

    addNotification({
      type: "success",
      message: "Payment method added successfully",
    })

    // Reset form
    setNewMethod({
      type: "card",
      cardNumber: "",
      cardName: "",
      cardExpiry: "",
      cardCvc: "",
    })

    setIsAddingMethod(false)
  }

  const handleSetDefaultMethod = (id: string) => {
    setPaymentMethods((prev) =>
      prev.map((method) => ({
        ...method,
        isDefault: method.id === id,
      })),
    )

    addNotification({
      type: "success",
      message: "Default payment method updated",
    })
  }

  const handleDeleteMethod = (id: string) => {
    const method = paymentMethods.find((m) => m.id === id)

    if (method?.isDefault) {
      addNotification({
        type: "error",
        message: "Cannot delete default payment method",
      })
      return
    }

    setPaymentMethods((prev) => prev.filter((method) => method.id !== id))

    addNotification({
      type: "success",
      message: "Payment method deleted successfully",
    })
  }

  const handleDeposit = () => {
    if (!depositAmount || isNaN(Number(depositAmount)) || Number(depositAmount) <= 0) {
      addNotification({
        type: "error",
        message: "Please enter a valid amount",
      })
      return
    }

    if (!depositMethod) {
      addNotification({
        type: "error",
        message: "Please select a payment method",
      })
      return
    }

    const amount = Number(depositAmount)
    const method = paymentMethods.find((m) => m.id === depositMethod)

    if (!method) return

    // Create transaction
    const transaction: Transaction = {
      id: `tx-${Date.now()}`,
      type: "deposit",
      amount,
      method: method.name,
      status: "pending",
      date: new Date().toISOString(),
      fee: 0,
      currency,
    }

    setTransactions((prev) => [transaction, ...prev])

    // Show loading notification
    const notificationId = addNotification({
      type: "info",
      message: `Processing deposit of ${currency === "USD" ? "$" : "₹"}${amount.toFixed(2)}`,
      duration: 0,
    })

    // Simulate transaction completion after 2 seconds
    setTimeout(() => {
      setTransactions((prev) => prev.map((tx) => (tx.id === transaction.id ? { ...tx, status: "completed" } : tx)))

      // Update user balance (convert INR to USD if needed)
      const usdAmount = currency === "USD" ? amount : amount / 83.65
      updateBalance("USD", usdAmount)

      // Remove loading notification and show success
      addNotification({
        type: "success",
        message: `Deposit of ${currency === "USD" ? "$" : "₹"}${amount.toFixed(2)} completed successfully`,
      })
    }, 2000)

    // Reset form
    setDepositAmount("")
    setDepositMethod("")
    setIsDepositing(false)
  }

  const handleWithdraw = () => {
    if (!withdrawAmount || isNaN(Number(withdrawAmount)) || Number(withdrawAmount) <= 0) {
      addNotification({
        type: "error",
        message: "Please enter a valid amount",
      })
      return
    }

    if (!withdrawMethod) {
      addNotification({
        type: "error",
        message: "Please select a payment method",
      })
      return
    }

    const amount = Number(withdrawAmount)
    const method = paymentMethods.find((m) => m.id === withdrawMethod)

    if (!method) return

    // Convert to USD for balance check if currency is INR
    const usdAmount = currency === "USD" ? amount : amount / 83.65

    // Check if user has enough balance
    if (!user || user.balance.USD < usdAmount) {
      addNotification({
        type: "error",
        message: "Insufficient balance",
      })
      return
    }

    // Calculate fee (0.5% for demo)
    const fee = amount * 0.005

    // Create transaction
    const transaction: Transaction = {
      id: `tx-${Date.now()}`,
      type: "withdrawal",
      amount,
      method: method.name,
      status: "pending",
      date: new Date().toISOString(),
      fee,
      currency,
    }

    setTransactions((prev) => [transaction, ...prev])

    // Show loading notification
    const notificationId = addNotification({
      type: "info",
      message: `Processing withdrawal of ${currency === "USD" ? "$" : "₹"}${amount.toFixed(2)}`,
      duration: 0,
    })

    // Simulate transaction completion after 2 seconds
    setTimeout(() => {
      setTransactions((prev) => prev.map((tx) => (tx.id === transaction.id ? { ...tx, status: "completed" } : tx)))

      //  => prev.map((tx) => (tx.id === transaction.id ? { ...tx, status: "completed" } : tx)))

      // Update user balance (convert INR to USD if needed)
      const usdFeeAmount = currency === "USD" ? fee : fee / 83.65
      const totalUsdAmount = usdAmount + usdFeeAmount
      updateBalance("USD", -totalUsdAmount)

      // Remove loading notification and show success
      addNotification({
        type: "success",
        message: `Withdrawal of ${currency === "USD" ? "$" : "₹"}${amount.toFixed(2)} completed successfully`,
      })
    }, 2000)

    // Reset form
    setWithdrawAmount("")
    setWithdrawMethod("")
    setIsWithdrawing(false)
  }

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading authentication...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    router.push("/login")
    return null
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold gradient-text">Payments</h1>
        <div className="flex items-center gap-2">
          <Button variant={currency === "USD" ? "default" : "outline"} size="sm" onClick={() => setCurrency("USD")}>
            USD
          </Button>
          <Button variant={currency === "INR" ? "default" : "outline"} size="sm" onClick={() => setCurrency("INR")}>
            INR
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-6">
        <Card className="border-primary/10 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Available Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {currency === "USD" ? "$" : "₹"}
                  {currency === "USD"
                    ? user?.balance.USD.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })
                    : (user?.balance.USD * 83.65).toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })}
                </div>
                <p className="text-xs text-muted-foreground">Available for trading or withdrawal</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="border-secondary/10 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Payment Methods</CardTitle>
            <CreditCard className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{paymentMethods.length}</div>
                <p className="text-xs text-muted-foreground">Connected payment methods</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="border-accent/10 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Transactions</CardTitle>
            <RefreshCw className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{transactions.filter((tx) => tx.status === "pending").length}</div>
                <p className="text-xs text-muted-foreground">Transactions being processed</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="border-primary/10 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Quick Actions</CardTitle>
            <Wallet className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
            <Button size="sm" onClick={() => setIsDepositing(true)}>
              <ArrowDown className="mr-2 h-4 w-4" />
              Deposit
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIsWithdrawing(true)}>
              <ArrowUp className="mr-2 h-4 w-4" />
              Withdraw
            </Button>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="methods">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="methods">Payment Methods</TabsTrigger>
          <TabsTrigger value="transactions">Transaction History</TabsTrigger>
        </TabsList>

        <TabsContent value="methods" className="mt-6">
          <Card className="border-primary/10 shadow-md">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Manage your payment methods for deposits and withdrawals</CardDescription>
              </div>

              <Dialog open={isAddingMethod} onOpenChange={setIsAddingMethod}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Method
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Payment Method</DialogTitle>
                    <DialogDescription>Add a new payment method for deposits and withdrawals.</DialogDescription>
                  </DialogHeader>

                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Payment Method Type</Label>
                      <RadioGroup
                        value={newMethod.type}
                        onValueChange={(value: "card" | "bank" | "crypto") =>
                          setNewMethod((prev) => ({ ...prev, type: value }))
                        }
                        className="flex flex-col gap-2"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="card" id="card" />
                          <Label htmlFor="card" className="flex items-center">
                            <CreditCard className="mr-2 h-4 w-4" />
                            Credit/Debit Card
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="bank" id="bank" />
                          <Label htmlFor="bank" className="flex items-center">
                            <DollarSign className="mr-2 h-4 w-4" />
                            Bank Account
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="crypto" id="crypto" />
                          <Label htmlFor="crypto" className="flex items-center">
                            <Wallet className="mr-2 h-4 w-4" />
                            Crypto Wallet
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    {newMethod.type === "card" && (
                      <>
                        <div className="space-y-2">
                          <Label htmlFor="cardNumber">Card Number</Label>
                          <Input
                            id="cardNumber"
                            placeholder="4242 4242 4242 4242"
                            value={newMethod.cardNumber}
                            onChange={(e) => setNewMethod((prev) => ({ ...prev, cardNumber: e.target.value }))}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="cardName">Cardholder Name</Label>
                          <Input
                            id="cardName"
                            placeholder="John Doe"
                            value={newMethod.cardName}
                            onChange={(e) => setNewMethod((prev) => ({ ...prev, cardName: e.target.value }))}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="cardExpiry">Expiry Date</Label>
                            <Input
                              id="cardExpiry"
                              placeholder="MM/YY"
                              value={newMethod.cardExpiry}
                              onChange={(e) => setNewMethod((prev) => ({ ...prev, cardExpiry: e.target.value }))}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="cardCvc">CVC</Label>
                            <Input
                              id="cardCvc"
                              placeholder="123"
                              value={newMethod.cardCvc}
                              onChange={(e) => setNewMethod((prev) => ({ ...prev, cardCvc: e.target.value }))}
                            />
                          </div>
                        </div>
                      </>
                    )}

                    {newMethod.type === "bank" && (
                      <div className="rounded-md bg-muted p-4">
                        <div className="flex items-start">
                          <AlertCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                          <div className="text-sm text-muted-foreground">
                            <p>Bank account setup requires verification.</p>
                            <p className="mt-1">
                              For this demo, we'll create a sample bank account without requiring actual details.
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    {newMethod.type === "crypto" && (
                      <div className="rounded-md bg-muted p-4">
                        <div className="flex items-start">
                          <AlertCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                          <div className="text-sm text-muted-foreground">
                            <p>Crypto wallet setup is simplified for this demo.</p>
                            <p className="mt-1">
                              In a real application, you would connect your wallet or provide a deposit address.
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddingMethod(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddPaymentMethod}>Add Payment Method</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 3 }).map((_, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-4">
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div>
                          <Skeleton className="h-5 w-32 mb-1" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                      </div>
                      <Skeleton className="h-8 w-20" />
                    </div>
                  ))}
                </div>
              ) : paymentMethods.length === 0 ? (
                <div className="text-center py-8">
                  <CreditCard className="mx-auto h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-4 text-lg font-medium">No Payment Methods</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Add a payment method to make deposits and withdrawals.
                  </p>
                  <Button className="mt-6" onClick={() => setIsAddingMethod(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Payment Method
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {paymentMethods.map((method) => (
                    <div
                      key={method.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:border-primary/50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                          {method.type === "card" ? (
                            <CreditCard className="h-5 w-5 text-primary" />
                          ) : method.type === "bank" ? (
                            <DollarSign className="h-5 w-5 text-primary" />
                          ) : (
                            <Wallet className="h-5 w-5 text-primary" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{method.name}</h3>
                            {method.isDefault && (
                              <Badge variant="outline" className="text-xs border-primary/50 text-primary">
                                Default
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{method.details}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {!method.isDefault && (
                          <Button variant="ghost" size="sm" onClick={() => handleSetDefaultMethod(method.id)}>
                            Set Default
                          </Button>
                        )}

                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteMethod(method.id)}
                          disabled={method.isDefault}
                        >
                          <Trash className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="mt-6">
          <Card className="border-primary/10 shadow-md">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Transaction History</CardTitle>
                  <CardDescription>Your deposit and withdrawal history</CardDescription>
                </div>

                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, index) => (
                    <div key={index} className="flex items-center justify-between py-3 border-b">
                      <Skeleton className="h-5 w-32" />
                      <Skeleton className="h-5 w-20" />
                      <Skeleton className="h-5 w-24" />
                      <Skeleton className="h-5 w-16" />
                      <Skeleton className="h-5 w-16" />
                      <Skeleton className="h-6 w-24" />
                    </div>
                  ))}
                </div>
              ) : transactions.length === 0 ? (
                <div className="text-center py-8">
                  <RefreshCw className="mx-auto h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-4 text-lg font-medium">No Transactions</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Make a deposit or withdrawal to see your transaction history.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b text-left">
                        <th className="pb-2 font-medium">Date</th>
                        <th className="pb-2 font-medium">Type</th>
                        <th className="pb-2 font-medium">Method</th>
                        <th className="pb-2 font-medium text-right">Amount</th>
                        <th className="pb-2 font-medium text-right">Fee</th>
                        <th className="pb-2 font-medium text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {transactions
                        .filter((tx) => (currency === "USD" ? tx.currency === "USD" : true))
                        .map((tx) => (
                          <tr key={tx.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                            <td className="py-3 text-sm">{new Date(tx.date).toLocaleString()}</td>
                            <td className={`py-3 ${tx.type === "deposit" ? "text-success" : "text-destructive"}`}>
                              {tx.type === "deposit" ? (
                                <span className="flex items-center">
                                  <ArrowDown className="mr-1 h-4 w-4" />
                                  Deposit
                                </span>
                              ) : (
                                <span className="flex items-center">
                                  <ArrowUp className="mr-1 h-4 w-4" />
                                  Withdrawal
                                </span>
                              )}
                            </td>
                            <td className="py-3">{tx.method}</td>
                            <td className="py-3 text-right font-medium">
                              {tx.currency === "USD" ? "$" : "₹"}
                              {tx.amount.toLocaleString(undefined, {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2,
                              })}
                            </td>
                            <td className="py-3 text-right text-muted-foreground">
                              {tx.currency === "USD" ? "$" : "₹"}
                              {tx.fee.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="py-3 text-center">
                              <Badge
                                variant={
                                  tx.status === "completed"
                                    ? "default"
                                    : tx.status === "pending"
                                      ? "outline"
                                      : "destructive"
                                }
                                className={
                                  tx.status === "completed"
                                    ? "bg-success/20 text-success hover:bg-success/30"
                                    : tx.status === "pending"
                                      ? "border-warning/50 text-warning"
                                      : ""
                                }
                              >
                                {tx.status === "completed" ? (
                                  <span className="flex items-center">
                                    <Check className="mr-1 h-3 w-3" />
                                    Completed
                                  </span>
                                ) : tx.status === "pending" ? (
                                  <span className="flex items-center">
                                    <RefreshCw className="mr-1 h-3 w-3 animate-spin" />
                                    Pending
                                  </span>
                                ) : (
                                  <span className="flex items-center">
                                    <AlertCircle className="mr-1 h-3 w-3" />
                                    Failed
                                  </span>
                                )}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Deposit Dialog */}
      <Dialog open={isDepositing} onOpenChange={setIsDepositing}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Deposit Funds</DialogTitle>
            <DialogDescription>Add funds to your trading account.</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="depositAmount">Amount ({currency})</Label>
              <Input
                id="depositAmount"
                type="number"
                placeholder="Enter amount"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="depositMethod">Payment Method</Label>
              {paymentMethods.length === 0 ? (
                <div className="rounded-md bg-muted p-4">
                  <div className="flex items-start">
                    <AlertCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                    <div className="text-sm text-muted-foreground">
                      <p>No payment methods available.</p>
                      <Button
                        variant="link"
                        className="p-0 h-auto text-sm"
                        onClick={() => {
                          setIsDepositing(false)
                          setIsAddingMethod(true)
                        }}
                      >
                        Add a payment method
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <Select value={depositMethod} onValueChange={setDepositMethod}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map((method) => (
                      <SelectItem key={method.id} value={method.id}>
                        {method.name} {method.isDefault && "(Default)"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            <div className="rounded-md bg-muted p-4">
              <div className="flex items-start">
                <AlertCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                <div className="text-sm text-muted-foreground">
                  <p>For demo purposes, deposits are processed instantly without actual payment processing.</p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDepositing(false)}>
              Cancel
            </Button>
            <Button onClick={handleDeposit} disabled={!depositAmount || !depositMethod || paymentMethods.length === 0}>
              Deposit Funds
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Withdraw Dialog */}
      <Dialog open={isWithdrawing} onOpenChange={setIsWithdrawing}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Withdraw Funds</DialogTitle>
            <DialogDescription>Withdraw funds from your trading account.</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="withdrawAmount">Amount ({currency})</Label>
              <Input
                id="withdrawAmount"
                type="number"
                placeholder="Enter amount"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Available balance: {currency === "USD" ? "$" : "₹"}
                {currency === "USD"
                  ? user?.balance.USD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                  : (user?.balance.USD * 83.65).toLocaleString(undefined, {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="withdrawMethod">Payment Method</Label>
              {paymentMethods.length === 0 ? (
                <div className="rounded-md bg-muted p-4">
                  <div className="flex items-start">
                    <AlertCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                    <div className="text-sm text-muted-foreground">
                      <p>No payment methods available.</p>
                      <Button
                        variant="link"
                        className="p-0 h-auto text-sm"
                        onClick={() => {
                          setIsWithdrawing(false)
                          setIsAddingMethod(true)
                        }}
                      >
                        Add a payment method
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <Select value={withdrawMethod} onValueChange={setWithdrawMethod}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map((method) => (
                      <SelectItem key={method.id} value={method.id}>
                        {method.name} {method.isDefault && "(Default)"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            <div className="rounded-md bg-muted p-4">
              <div className="flex items-start">
                <AlertCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                <div className="text-sm text-muted-foreground">
                  <p>A 0.5% fee applies to all withdrawals.</p>
                  <p className="mt-1">For demo purposes, withdrawals are processed instantly.</p>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsWithdrawing(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleWithdraw}
              disabled={
                !withdrawAmount ||
                !withdrawMethod ||
                paymentMethods.length === 0 ||
                !user ||
                (currency === "USD"
                  ? user.balance.USD < Number(withdrawAmount)
                  : user.balance.USD < Number(withdrawAmount) / 83.65)
              }
            >
              Withdraw Funds
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

