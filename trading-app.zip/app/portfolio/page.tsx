"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/lib/auth-context"
import { ArrowDown, ArrowUp, Briefcase, DollarSign, TrendingUp } from "lucide-react"
import { connectToMarketStream } from "@/lib/websocket-client"
import { Progress } from "@/components/ui/progress"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

type PortfolioAsset = {
  symbol: string
  name: string
  amount: number
  price: number
  change: number
  value: number
  allocation: number
  history: { date: string; value: number }[]
}

type PortfolioHistory = {
  date: string
  value: number
}

export default function PortfolioPage() {
  const [assets, setAssets] = useState<PortfolioAsset[]>([])
  const [portfolioValue, setPortfolioValue] = useState(0)
  const [portfolioChange, setPortfolioChange] = useState(0)
  const [portfolioChangePercent, setPortfolioChangePercent] = useState(0)
  const [portfolioHistory, setPortfolioHistory] = useState<PortfolioHistory[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [authLoading, isAuthenticated, router])

  useEffect(() => {
    if (!user) return

    // Initialize portfolio assets
    const initialAssets: PortfolioAsset[] = []
    let totalValue = 0

    if (user.balance.BTC > 0) {
      const value = user.balance.BTC * 68432.12
      totalValue += value

      initialAssets.push({
        symbol: "BTC",
        name: "Bitcoin",
        amount: user.balance.BTC,
        price: 68432.12,
        change: 2.34,
        value,
        allocation: 0, // Will calculate after all assets are added
        history: generateAssetHistory(value),
      })
    }

    if (user.balance.ETH > 0) {
      const value = user.balance.ETH * 3845.67
      totalValue += value

      initialAssets.push({
        symbol: "ETH",
        name: "Ethereum",
        amount: user.balance.ETH,
        price: 3845.67,
        change: 1.78,
        value,
        allocation: 0, // Will calculate after all assets are added
        history: generateAssetHistory(value),
      })
    }

    // Add some sample stocks for demonstration
    const aaplAmount = 5
    const aaplValue = aaplAmount * 173.45
    totalValue += aaplValue

    initialAssets.push({
      symbol: "AAPL",
      name: "Apple Inc.",
      amount: aaplAmount,
      price: 173.45,
      change: 1.23,
      value: aaplValue,
      allocation: 0, // Will calculate after all assets are added
      history: generateAssetHistory(aaplValue),
    })

    // Calculate allocations
    const assetsWithAllocation = initialAssets.map((asset) => ({
      ...asset,
      allocation: (asset.value / totalValue) * 100,
    }))

    setAssets(assetsWithAllocation)
    setPortfolioValue(totalValue)

    // Generate portfolio history
    setPortfolioHistory(generatePortfolioHistory(totalValue))

    // Calculate portfolio change
    const yesterdayValue = totalValue * 0.98 // Simulated previous value
    const change = totalValue - yesterdayValue
    const changePercent = (change / yesterdayValue) * 100

    setPortfolioChange(change)
    setPortfolioChangePercent(changePercent)
    setIsLoading(false)
  }, [user])

  useEffect(() => {
    const symbols = assets.map((asset) => asset.symbol)

    if (symbols.length === 0) return

    const { disconnect } = connectToMarketStream((data) => {
      if (symbols.includes(data.symbol)) {
        setAssets((prev) => {
          const updatedAssets = prev.map((asset) => {
            if (asset.symbol === data.symbol) {
              const newValue = asset.amount * data.price
              return {
                ...asset,
                price: data.price,
                change: data.change,
                value: newValue,
              }
            }
            return asset
          })

          // Recalculate total value and allocations
          const newTotalValue = updatedAssets.reduce((sum, asset) => sum + asset.value, 0)

          const assetsWithUpdatedAllocation = updatedAssets.map((asset) => ({
            ...asset,
            allocation: (asset.value / newTotalValue) * 100,
          }))

          setPortfolioValue(newTotalValue)

          return assetsWithUpdatedAllocation
        })
      }
    })

    return () => {
      disconnect()
    }
  }, [assets])

  // Helper function to generate random asset history
  function generateAssetHistory(currentValue: number) {
    const history = []
    const now = new Date()

    for (let i = 30; i >= 0; i--) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)

      // Generate a value that trends toward the current value
      const randomFactor = 0.9 + Math.random() * 0.2
      const value = i === 0 ? currentValue : currentValue * (0.85 + (i / 30) * 0.3) * randomFactor

      history.push({
        date: date.toISOString().split("T")[0],
        value,
      })
    }

    return history
  }

  // Helper function to generate portfolio history
  function generatePortfolioHistory(currentValue: number) {
    const history = []
    const now = new Date()

    for (let i = 30; i >= 0; i--) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)

      // Generate a value that trends toward the current value
      const randomFactor = 0.95 + Math.random() * 0.1
      const value = i === 0 ? currentValue : currentValue * (0.9 + (i / 30) * 0.2) * randomFactor

      history.push({
        date: date.toISOString().split("T")[0],
        value,
      })
    }

    return history
  }

  if (authLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-6">
      <h1 className="text-3xl font-bold mb-6">Portfolio</h1>

      <div className="grid gap-6 md:grid-cols-3 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${portfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div
              className={`flex items-center text-xs ${portfolioChangePercent >= 0 ? "text-green-500" : "text-red-500"}`}
            >
              {portfolioChangePercent >= 0 ? (
                <ArrowUp className="mr-1 h-3 w-3" />
              ) : (
                <ArrowDown className="mr-1 h-3 w-3" />
              )}
              ${Math.abs(portfolioChange).toFixed(2)} ({Math.abs(portfolioChangePercent).toFixed(2)}%)
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Assets</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{assets.length}</div>
            <p className="text-xs text-muted-foreground">
              {assets.length > 0 ? "Diversified portfolio" : "No assets yet"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Performance</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {portfolioChangePercent >= 0 ? "+" : ""}
              {portfolioChangePercent.toFixed(2)}%
            </div>
            <p className="text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3 mb-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Portfolio Performance</CardTitle>
            <CardDescription>30-day historical performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ChartContainer
                config={{
                  value: {
                    label: "Portfolio Value",
                    color: "hsl(var(--chart-1))",
                  },
                }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={portfolioHistory}>
                    <XAxis
                      dataKey="date"
                      tickFormatter={(value) => {
                        const date = new Date(value)
                        return `${date.getMonth() + 1}/${date.getDate()}`
                      }}
                      tickMargin={10}
                    />
                    <YAxis tickFormatter={(value) => `$${value.toLocaleString()}`} width={80} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line
                      type="monotone"
                      dataKey="value"
                      name="Portfolio Value"
                      stroke="var(--color-value)"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Asset Allocation</CardTitle>
            <CardDescription>Portfolio distribution</CardDescription>
          </CardHeader>
          <CardContent>
            {assets.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <p>No assets in your portfolio</p>
              </div>
            ) : (
              <div className="space-y-4">
                {assets.map((asset) => (
                  <div key={asset.symbol} className="space-y-1">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">{asset.symbol}</div>
                      <div className="text-sm text-muted-foreground">{asset.allocation.toFixed(1)}%</div>
                    </div>
                    <Progress value={asset.allocation} className="h-2" />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Assets</CardTitle>
          <CardDescription>Detailed view of your portfolio assets</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All Assets</TabsTrigger>
              <TabsTrigger value="crypto">Crypto</TabsTrigger>
              <TabsTrigger value="stocks">Stocks</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-4">
              <AssetTable assets={assets} />
            </TabsContent>
            <TabsContent value="crypto" className="mt-4">
              <AssetTable assets={assets.filter((asset) => ["BTC", "ETH"].includes(asset.symbol))} />
            </TabsContent>
            <TabsContent value="stocks" className="mt-4">
              <AssetTable assets={assets.filter((asset) => !["BTC", "ETH"].includes(asset.symbol))} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

function AssetTable({ assets }: { assets: PortfolioAsset[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b text-left">
            <th className="pb-2 font-medium">Asset</th>
            <th className="pb-2 font-medium text-right">Price</th>
            <th className="pb-2 font-medium text-right">24h Change</th>
            <th className="pb-2 font-medium text-right">Holdings</th>
            <th className="pb-2 font-medium text-right">Value</th>
            <th className="pb-2 font-medium text-right">Allocation</th>
          </tr>
        </thead>
        <tbody>
          {assets.length === 0 ? (
            <tr>
              <td colSpan={6} className="py-4 text-center text-muted-foreground">
                No assets found
              </td>
            </tr>
          ) : (
            assets.map((asset) => (
              <tr key={asset.symbol} className="border-b last:border-0 hover:bg-muted/50">
                <td className="py-3">
                  <div className="font-medium">{asset.symbol}</div>
                  <div className="text-sm text-muted-foreground">{asset.name}</div>
                </td>
                <td className="py-3 text-right font-medium">
                  ${asset.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className={`py-3 text-right ${asset.change >= 0 ? "text-green-500" : "text-red-500"}`}>
                  <span className="flex items-center justify-end">
                    {asset.change >= 0 ? <ArrowUp className="mr-1 h-4 w-4" /> : <ArrowDown className="mr-1 h-4 w-4" />}
                    {Math.abs(asset.change).toFixed(2)}%
                  </span>
                </td>
                <td className="py-3 text-right">
                  {asset.amount.toLocaleString(undefined, {
                    minimumFractionDigits: ["BTC", "ETH"].includes(asset.symbol) ? 8 : 2,
                    maximumFractionDigits: ["BTC", "ETH"].includes(asset.symbol) ? 8 : 2,
                  })}
                </td>
                <td className="py-3 text-right font-medium">
                  ${asset.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </td>
                <td className="py-3 text-right">{asset.allocation.toFixed(1)}%</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}

