"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"
import { useNotification } from "@/components/notification-system"
import { AlertCircle, ArrowDown, ArrowUp, Bot, Clock, Play, Plus, Settings, Square, Trash } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type TradingBot = {
  id: string
  name: string
  description: string
  symbol: string
  strategy: "grid" | "dca" | "trend" | "arbitrage"
  status: "active" | "paused" | "stopped"
  profit: number
  profitPercent: number
  trades: number
  createdAt: string
}

export default function BotsPage() {
  const [bots, setBots] = useState<TradingBot[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [newBot, setNewBot] = useState({
    name: "",
    symbol: "BTC",
    strategy: "grid" as const,
  })
  const { isAuthenticated, isLoading: authLoading } = useAuth()
  const { addNotification } = useNotification()
  const router = useRouter()

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push("/login")
    }
  }, [authLoading, isAuthenticated, router])

  useEffect(() => {
    // Initialize sample bots
    const sampleBots: TradingBot[] = [
      {
        id: "bot-1",
        name: "BTC Grid Trader",
        description: "Buys low and sells high in a predefined price range",
        symbol: "BTC",
        strategy: "grid",
        status: "active",
        profit: 1250.75,
        profitPercent: 3.2,
        trades: 42,
        createdAt: "2023-03-15T10:30:00Z",
      },
      {
        id: "bot-2",
        name: "ETH DCA Bot",
        description: "Dollar-cost averaging for Ethereum",
        symbol: "ETH",
        strategy: "dca",
        status: "active",
        profit: 580.25,
        profitPercent: 2.1,
        trades: 15,
        createdAt: "2023-04-20T14:45:00Z",
      },
      {
        id: "bot-3",
        name: "AAPL Trend Follower",
        description: "Follows market trends for Apple stock",
        symbol: "AAPL",
        strategy: "trend",
        status: "paused",
        profit: -120.5,
        profitPercent: -0.8,
        trades: 7,
        createdAt: "2023-05-10T09:15:00Z",
      },
    ]

    setBots(sampleBots)
    setIsLoading(false)
  }, [])

  const handleCreateBot = () => {
    if (!newBot.name) {
      addNotification({
        type: "error",
        message: "Please enter a name for your bot",
      })
      return
    }

    const bot: TradingBot = {
      id: `bot-${Date.now()}`,
      name: newBot.name,
      description: getStrategyDescription(newBot.strategy),
      symbol: newBot.symbol,
      strategy: newBot.strategy,
      status: "active",
      profit: 0,
      profitPercent: 0,
      trades: 0,
      createdAt: new Date().toISOString(),
    }

    setBots((prev) => [bot, ...prev])

    addNotification({
      type: "success",
      message: `Trading bot "${newBot.name}" created successfully`,
    })

    // Reset form
    setNewBot({
      name: "",
      symbol: "BTC",
      strategy: "grid",
    })

    setIsCreating(false)
  }

  const handleToggleStatus = (id: string) => {
    setBots((prev) =>
      prev.map((bot) => {
        if (bot.id === id) {
          const newStatus = bot.status === "active" ? "paused" : "active"

          addNotification({
            type: "success",
            message: `Bot "${bot.name}" ${newStatus === "active" ? "activated" : "paused"}`,
          })

          return {
            ...bot,
            status: newStatus,
          }
        }
        return bot
      }),
    )
  }

  const handleDeleteBot = (id: string) => {
    const bot = bots.find((b) => b.id === id)

    if (bot) {
      setBots((prev) => prev.filter((b) => b.id !== id))

      addNotification({
        type: "success",
        message: `Bot "${bot.name}" deleted successfully`,
      })
    }
  }

  const getStrategyDescription = (strategy: string) => {
    switch (strategy) {
      case "grid":
        return "Buys low and sells high in a predefined price range"
      case "dca":
        return "Dollar-cost averaging strategy for regular purchases"
      case "trend":
        return "Follows market trends using technical indicators"
      case "arbitrage":
        return "Exploits price differences between exchanges"
      default:
        return "Custom trading strategy"
    }
  }

  if (authLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Trading Bots</h1>

        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Bot
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Trading Bot</DialogTitle>
              <DialogDescription>
                Configure your automated trading bot. The bot will execute trades based on your selected strategy.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Bot Name</Label>
                <Input
                  id="name"
                  placeholder="My Trading Bot"
                  value={newBot.name}
                  onChange={(e) => setNewBot((prev) => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="symbol">Trading Pair</Label>
                <Select
                  value={newBot.symbol}
                  onValueChange={(value) => setNewBot((prev) => ({ ...prev, symbol: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select trading pair" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                    <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                    <SelectItem value="AAPL">Apple Inc. (AAPL)</SelectItem>
                    <SelectItem value="MSFT">Microsoft Corp. (MSFT)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="strategy">Trading Strategy</Label>
                <Select
                  value={newBot.strategy}
                  onValueChange={(value: "grid" | "dca" | "trend" | "arbitrage") =>
                    setNewBot((prev) => ({ ...prev, strategy: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select strategy" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grid">Grid Trading</SelectItem>
                    <SelectItem value="dca">Dollar-Cost Averaging</SelectItem>
                    <SelectItem value="trend">Trend Following</SelectItem>
                    <SelectItem value="arbitrage">Arbitrage</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="rounded-md bg-muted p-4">
                <div className="flex items-start">
                  <AlertCircle className="mr-2 h-5 w-5 text-muted-foreground" />
                  <div className="text-sm text-muted-foreground">
                    <p className="font-medium">{getStrategyDescription(newBot.strategy)}</p>
                    <p className="mt-1">
                      Trading bots operate automatically based on predefined rules. You can pause or stop the bot at any
                      time.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreating(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateBot}>Create Bot</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : bots.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <Bot className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-medium">No Trading Bots</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Create your first trading bot to automate your trading strategy.
            </p>
            <Button className="mt-6" onClick={() => setIsCreating(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Bot
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {bots.map((bot) => (
            <Card key={bot.id}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <Badge
                    variant={bot.status === "active" ? "default" : bot.status === "paused" ? "outline" : "secondary"}
                    className="mb-2"
                  >
                    {bot.status === "active" ? (
                      <>
                        <Play className="mr-1 h-3 w-3" /> Active
                      </>
                    ) : bot.status === "paused" ? (
                      <>
                        <Square className="mr-1 h-3 w-3" /> Paused
                      </>
                    ) : (
                      <>
                        <Clock className="mr-1 h-3 w-3" /> Stopped
                      </>
                    )}
                  </Badge>

                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" asChild>
                      <Link href={`/bots/${bot.id}/settings`}>
                        <Settings className="h-4 w-4" />
                        <span className="sr-only">Settings</span>
                      </Link>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteBot(bot.id)}>
                      <Trash className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                </div>

                <CardTitle>{bot.name}</CardTitle>
                <CardDescription>{bot.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Symbol</div>
                    <div>{bot.symbol}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Strategy</div>
                    <div className="capitalize">{bot.strategy}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Profit</div>
                    <div className={`flex items-center ${bot.profit >= 0 ? "text-green-500" : "text-red-500"}`}>
                      {bot.profit >= 0 ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />}$
                      {Math.abs(bot.profit).toFixed(2)} ({Math.abs(bot.profitPercent).toFixed(2)}%)
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Trades</div>
                    <div>{bot.trades}</div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t pt-4">
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id={`bot-status-${bot.id}`}
                      checked={bot.status === "active"}
                      onCheckedChange={() => handleToggleStatus(bot.id)}
                    />
                    <Label htmlFor={`bot-status-${bot.id}`}>{bot.status === "active" ? "Active" : "Paused"}</Label>
                  </div>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/bots/${bot.id}`}>View Details</Link>
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

function Link({ href, children, ...props }: React.ComponentProps<"a"> & { href: string }) {
  const router = useRouter()

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault()
    router.push(href)
  }

  return (
    <a href={href} onClick={handleClick} {...props}>
      {children}
    </a>
  )
}

