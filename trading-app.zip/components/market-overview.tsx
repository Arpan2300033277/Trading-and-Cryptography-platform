"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowDown, ArrowUp, Search, Star } from "lucide-react"
import { connectToMarketStream } from "@/lib/websocket-client"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { Badge } from "@/components/ui/badge"
import { useNotification } from "@/components/notification-system"
import { Skeleton } from "@/components/ui/skeleton"

type MarketData = {
  symbol: string
  name: string
  price: number
  change: number
  volume: string
  marketCap: string
  type: "stock" | "crypto"
  market: "global" | "india"
  isFavorite?: boolean
}

export function MarketOverview() {
  const [marketData, setMarketData] = useState<MarketData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()
  const { addNotification } = useNotification()

  useEffect(() => {
    // Initialize with global and Indian market data
    const initialData: MarketData[] = [
      // Global Cryptocurrencies
      {
        symbol: "BTC",
        name: "Bitcoin",
        price: 68432.12,
        change: 2.34,
        volume: "32.1B",
        marketCap: "1.34T",
        type: "crypto",
        market: "global",
        isFavorite: true,
      },
      {
        symbol: "ETH",
        name: "Ethereum",
        price: 3845.67,
        change: 1.78,
        volume: "18.7B",
        marketCap: "462.3B",
        type: "crypto",
        market: "global",
        isFavorite: false,
      },
      {
        symbol: "SOL",
        name: "Solana",
        price: 142.34,
        change: 5.67,
        volume: "5.2B",
        marketCap: "61.5B",
        type: "crypto",
        market: "global",
        isFavorite: false,
      },
      {
        symbol: "ADA",
        name: "Cardano",
        price: 0.58,
        change: -1.23,
        volume: "1.8B",
        marketCap: "20.7B",
        type: "crypto",
        market: "global",
        isFavorite: false,
      },

      // Global Stocks
      {
        symbol: "AAPL",
        name: "Apple Inc.",
        price: 173.45,
        change: 1.23,
        volume: "52.3M",
        marketCap: "2.73T",
        type: "stock",
        market: "global",
        isFavorite: true,
      },
      {
        symbol: "MSFT",
        name: "Microsoft Corp.",
        price: 328.79,
        change: 2.56,
        volume: "23.1M",
        marketCap: "2.45T",
        type: "stock",
        market: "global",
        isFavorite: false,
      },
      {
        symbol: "GOOGL",
        name: "Alphabet Inc.",
        price: 142.56,
        change: -0.87,
        volume: "18.7M",
        marketCap: "1.82T",
        type: "stock",
        market: "global",
        isFavorite: false,
      },
      {
        symbol: "AMZN",
        name: "Amazon.com Inc.",
        price: 178.23,
        change: 1.45,
        volume: "31.2M",
        marketCap: "1.85T",
        type: "stock",
        market: "global",
        isFavorite: false,
      },

      // Indian Stocks
      {
        symbol: "RELIANCE",
        name: "Reliance Industries",
        price: 2934.75,
        change: 1.87,
        volume: "8.2M",
        marketCap: "19.8T",
        type: "stock",
        market: "india",
        isFavorite: false,
      },
      {
        symbol: "TCS",
        name: "Tata Consultancy Services",
        price: 3567.8,
        change: 0.92,
        volume: "2.1M",
        marketCap: "13.1T",
        type: "stock",
        market: "india",
        isFavorite: false,
      },
      {
        symbol: "HDFCBANK",
        name: "HDFC Bank",
        price: 1678.45,
        change: -0.54,
        volume: "5.7M",
        marketCap: "9.3T",
        type: "stock",
        market: "india",
        isFavorite: false,
      },
      {
        symbol: "INFY",
        name: "Infosys",
        price: 1456.3,
        change: 1.23,
        volume: "4.2M",
        marketCap: "6.1T",
        type: "stock",
        market: "india",
        isFavorite: false,
      },
      {
        symbol: "TATAMOTORS",
        name: "Tata Motors",
        price: 876.25,
        change: 3.45,
        volume: "12.3M",
        marketCap: "2.9T",
        type: "stock",
        market: "india",
        isFavorite: false,
      },

      // Cryptocurrencies in INR
      {
        symbol: "BTC-INR",
        name: "Bitcoin (INR)",
        price: 5723456.78,
        change: 2.34,
        volume: "2.7B",
        marketCap: "112.1T",
        type: "crypto",
        market: "india",
        isFavorite: false,
      },
      {
        symbol: "ETH-INR",
        name: "Ethereum (INR)",
        price: 321456.89,
        change: 1.78,
        volume: "1.5B",
        marketCap: "38.6T",
        type: "crypto",
        market: "india",
        isFavorite: false,
      },
      {
        symbol: "SOL-INR",
        name: "Solana (INR)",
        price: 11876.45,
        change: 5.67,
        volume: "432M",
        marketCap: "5.1T",
        type: "crypto",
        market: "india",
        isFavorite: false,
      },
    ]

    setMarketData(initialData)

    // Simulate loading delay
    setTimeout(() => {
      setIsLoading(false)
    }, 1000)
  }, [])

  useEffect(() => {
    const { disconnect } = connectToMarketStream((data) => {
      setMarketData((prevData) => {
        return prevData.map((item) => {
          // Update both global and INR prices for matching symbols
          if (item.symbol === data.symbol || item.symbol === `${data.symbol}-INR`) {
            const price =
              item.market === "india" && item.type === "crypto"
                ? data.price * 83.65 // Approximate USD to INR conversion
                : data.price

            return {
              ...item,
              price,
              change: data.change,
            }
          }
          return item
        })
      })
    })

    return () => {
      disconnect()
    }
  }, [])

  const handleRowClick = (symbol: string) => {
    router.push(`/trade/${symbol}`)
  }

  const toggleFavorite = (e: React.MouseEvent, symbol: string) => {
    e.stopPropagation()
    setMarketData((prevData) => {
      return prevData.map((item) => {
        if (item.symbol === symbol) {
          const newState = !item.isFavorite

          // Show notification
          addNotification({
            type: "success",
            message: newState ? `Added ${symbol} to favorites` : `Removed ${symbol} from favorites`,
          })

          return {
            ...item,
            isFavorite: newState,
          }
        }
        return item
      })
    })
  }

  const filteredMarketData = marketData.filter((item) => {
    if (!searchQuery) return true

    const query = searchQuery.toLowerCase()
    return item.symbol.toLowerCase().includes(query) || item.name.toLowerCase().includes(query)
  })

  return (
    <Card className="relative overflow-hidden border-primary/10 shadow-lg">
      <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary/5 rounded-full blur-xl"></div>
      <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-secondary/5 rounded-full blur-xl"></div>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <CardTitle className="text-xl text-primary">Market Overview</CardTitle>
            <CardDescription>Real-time market data for global and Indian markets</CardDescription>
          </div>
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search markets..."
              className="pl-10 border-primary/20 focus-visible:ring-primary"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
            <TabsTrigger value="global">Global</TabsTrigger>
            <TabsTrigger value="india">Indian</TabsTrigger>
            <TabsTrigger value="crypto">Crypto</TabsTrigger>
          </TabsList>

          {isLoading ? (
            <div className="mt-4 space-y-2">
              {Array.from({ length: 5 }).map((_, index) => (
                <div key={index} className="flex items-center space-x-4 p-2">
                  <Skeleton className="h-4 w-4 rounded-full" />
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="ml-auto h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                </div>
              ))}
            </div>
          ) : (
            <>
              <TabsContent value="all" className="mt-4">
                <MarketTable data={filteredMarketData} onRowClick={handleRowClick} onToggleFavorite={toggleFavorite} />
              </TabsContent>
              <TabsContent value="favorites" className="mt-4">
                <MarketTable
                  data={filteredMarketData.filter((item) => item.isFavorite)}
                  onRowClick={handleRowClick}
                  onToggleFavorite={toggleFavorite}
                />
              </TabsContent>
              <TabsContent value="global" className="mt-4">
                <MarketTable
                  data={filteredMarketData.filter((item) => item.market === "global")}
                  onRowClick={handleRowClick}
                  onToggleFavorite={toggleFavorite}
                />
              </TabsContent>
              <TabsContent value="india" className="mt-4">
                <MarketTable
                  data={filteredMarketData.filter((item) => item.market === "india")}
                  onRowClick={handleRowClick}
                  onToggleFavorite={toggleFavorite}
                />
              </TabsContent>
              <TabsContent value="crypto" className="mt-4">
                <MarketTable
                  data={filteredMarketData.filter((item) => item.type === "crypto")}
                  onRowClick={handleRowClick}
                  onToggleFavorite={toggleFavorite}
                />
              </TabsContent>
            </>
          )}
        </Tabs>
      </CardContent>
    </Card>
  )
}

function MarketTable({
  data,
  onRowClick,
  onToggleFavorite,
}: {
  data: MarketData[]
  onRowClick: (symbol: string) => void
  onToggleFavorite: (e: React.MouseEvent, symbol: string) => void
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b text-left">
            <th className="pb-2 font-medium w-10"></th>
            <th className="pb-2 font-medium">Symbol</th>
            <th className="pb-2 font-medium">Name</th>
            <th className="pb-2 font-medium text-right">Price</th>
            <th className="pb-2 font-medium text-right">24h Change</th>
            <th className="pb-2 font-medium text-right hidden md:table-cell">Volume</th>
            <th className="pb-2 font-medium text-right hidden md:table-cell">Market Cap</th>
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td colSpan={7} className="py-4 text-center text-muted-foreground">
                No markets found
              </td>
            </tr>
          ) : (
            data.map((item) => (
              <tr
                key={item.symbol}
                className="border-b last:border-0 hover:bg-muted/50 cursor-pointer transition-colors"
                onClick={() => onRowClick(item.symbol)}
              >
                <td className="py-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-8 w-8 ${item.isFavorite ? "text-yellow-500" : "text-muted-foreground"}`}
                    onClick={(e) => onToggleFavorite(e, item.symbol)}
                  >
                    <Star className="h-4 w-4" fill={item.isFavorite ? "currentColor" : "none"} />
                    <span className="sr-only">{item.isFavorite ? "Remove from favorites" : "Add to favorites"}</span>
                  </Button>
                </td>
                <td className="py-3 font-medium">
                  <div className="flex items-center">
                    <Badge
                      variant="outline"
                      className={`mr-2 px-1.5 py-0 text-xs ${
                        item.market === "india"
                          ? "border-secondary/50 text-secondary"
                          : "border-primary/50 text-primary"
                      }`}
                    >
                      {item.type === "crypto" ? "CRYPTO" : "STOCK"}
                    </Badge>
                    {item.symbol}
                  </div>
                </td>
                <td className="py-3 text-muted-foreground">{item.name}</td>
                <td className="py-3 text-right font-medium">
                  {item.market === "india" ? "₹" : "$"}
                  {formatPrice(item.price)}
                </td>
                <td className={`py-3 text-right ${item.change >= 0 ? "text-success" : "text-destructive"}`}>
                  <span className="flex items-center justify-end">
                    {item.change >= 0 ? <ArrowUp className="mr-1 h-4 w-4" /> : <ArrowDown className="mr-1 h-4 w-4" />}
                    {Math.abs(item.change).toFixed(2)}%
                  </span>
                </td>
                <td className="py-3 text-right text-muted-foreground hidden md:table-cell">{item.volume}</td>
                <td className="py-3 text-right text-muted-foreground hidden md:table-cell">{item.marketCap}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}

// Helper function to format prices correctly based on their value
function formatPrice(price: number): string {
  if (price >= 10000) {
    // For large numbers like INR crypto prices, show no decimal places
    return price.toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })
  } else if (price >= 1000) {
    // For prices between 1000-10000, show 1 decimal place
    return price.toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 1,
    })
  } else if (price >= 1) {
    // For prices between 1-1000, show 2 decimal places
    return price.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  } else {
    // For prices less than 1 (like ADA), show more decimal places
    return price.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 6,
    })
  }
}

