"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Briefcase,
  Clock,
  CreditCard,
  Globe,
  Home,
  LineChart,
  Bell,
  Moon,
  Sun,
  Sparkles,
  LogOut,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTheme } from "@/components/theme-provider"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/lib/auth-context"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"

export function AppSidebar() {
  const pathname = usePathname()
  const { theme, setTheme } = useTheme()
  const { user, logout } = useAuth()

  const routes = [
    {
      title: "Dashboard",
      icon: Home,
      href: "/",
      active: pathname === "/",
    },
    {
      title: "Markets",
      icon: Globe,
      href: "/markets",
      active: pathname === "/markets",
    },
    {
      title: "Portfolio",
      icon: Briefcase,
      href: "/portfolio",
      active: pathname === "/portfolio",
    },
    {
      title: "Orders",
      icon: Clock,
      href: "/orders",
      active: pathname === "/orders",
    },
    {
      title: "Trading Bots",
      icon: Sparkles,
      href: "/bots",
      active: pathname === "/bots",
    },
    {
      title: "Price Alerts",
      icon: Bell,
      href: "/alerts",
      active: pathname === "/alerts",
    },
    {
      title: "Analytics",
      icon: LineChart,
      href: "/analytics",
      active: pathname === "/analytics",
    },
    {
      title: "Payments",
      icon: CreditCard,
      href: "/payments",
      active: pathname === "/payments",
    },
  ]

  return (
    <Sidebar>
      <SidebarHeader className="border-b px-6 py-5">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <div className="relative w-8 h-8 flex items-center justify-center">
            <div className="absolute inset-0 bg-primary rounded-full opacity-20 animate-pulse-glow"></div>
            <BarChart3 className="h-5 w-5 text-primary" />
          </div>
          <div>
            <span className="text-primary">Trade</span>
            <span>Pulse</span>
          </div>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {routes.map((route) => (
            <SidebarMenuItem key={route.href}>
              <SidebarMenuButton asChild isActive={route.active}>
                <Link href={route.href}>
                  <route.icon className="h-5 w-5" />
                  <span>{route.title}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="border-t p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src="/placeholder.svg" alt={user?.name || "User"} />
              <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div className="text-sm">
              <p className="font-medium">{user?.name || "User"}</p>
              <p className="text-xs text-muted-foreground truncate max-w-[100px]">
                {user?.email || "user@example.com"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            <Button variant="ghost" size="icon" onClick={logout} aria-label="Logout">
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}

