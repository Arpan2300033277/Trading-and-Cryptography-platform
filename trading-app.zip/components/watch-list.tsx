"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowDown, ArrowUp, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { connectToMarketStream } from "@/lib/websocket-client"

type WatchlistItem = {
  symbol: string
  price: number
  change: number
}

export function WatchList() {
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([
    { symbol: "BTC", price: 68432.12, change: 2.34 },
    { symbol: "ETH", price: 3845.67, change: 1.78 },
    { symbol: "AAPL", price: 173.45, change: 1.23 },
    { symbol: "MSFT", price: 328.79, change: 2.56 },
  ])

  useEffect(() => {
    const { disconnect } = connectToMarketStream((data) => {
      setWatchlist((prev) => {
        return prev.map((item) => {
          if (item.symbol === data.symbol) {
            return {
              ...item,
              price: data.price,
              change: data.change,
            }
          }
          return item
        })
      })
    })

    return () => {
      disconnect()
    }
  }, [])

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between py-4">
        <CardTitle className="text-base">Watchlist</CardTitle>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Plus className="h-4 w-4" />
          <span className="sr-only">Add to watchlist</span>
        </Button>
      </CardHeader>
      <CardContent className="px-2">
        <div className="space-y-1">
          {watchlist.map((item) => (
            <div
              key={item.symbol}
              className="flex items-center justify-between rounded-md px-3 py-2 hover:bg-muted/50 cursor-pointer"
            >
              <div className="font-medium">{item.symbol}</div>
              <div className="flex flex-col items-end">
                <div className="font-medium">
                  ${item.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className={`text-xs flex items-center ${item.change >= 0 ? "text-green-500" : "text-red-500"}`}>
                  {item.change >= 0 ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />}
                  {Math.abs(item.change).toFixed(2)}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

