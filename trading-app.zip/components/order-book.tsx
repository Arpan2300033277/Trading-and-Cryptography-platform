"use client"

import { useEffect, useState, useCallback, useMemo } from "react"
import { connectToOrderBookStream } from "@/lib/websocket-client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type OrderBookEntry = {
  price: number
  amount: number
  total: number
}

export function OrderBook() {
  const [symbol, setSymbol] = useState("BTC")
  const [asks, setAsks] = useState<OrderBookEntry[]>([])
  const [bids, setBids] = useState<OrderBookEntry[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Memoize the max total for visualization
  const maxTotal = useMemo(() => {
    const askMax = asks.length > 0 ? asks[asks.length - 1].total : 0
    const bidMax = bids.length > 0 ? bids[bids.length - 1].total : 0
    return Math.max(askMax, bidMax)
  }, [asks, bids])

  const handleSymbolChange = useCallback((value: string) => {
    setSymbol(value)
    setIsLoading(true)
  }, [])

  useEffect(() => {
    // Generate initial order book data
    const generateOrderBook = () => {
      const basePrice = symbol === "BTC" ? 68432.12 : symbol === "ETH" ? 3845.67 : symbol === "AAPL" ? 173.45 : 328.79

      const newAsks: OrderBookEntry[] = []
      const newBids: OrderBookEntry[] = []

      // Generate asks (sell orders)
      let askTotal = 0
      for (let i = 0; i < 10; i++) {
        const price = basePrice + (i + 1) * (basePrice * 0.0005)
        const amount = Math.random() * 5 + 0.1
        askTotal += amount
        newAsks.push({
          price,
          amount,
          total: askTotal,
        })
      }

      // Generate bids (buy orders)
      let bidTotal = 0
      for (let i = 0; i < 10; i++) {
        const price = basePrice - (i + 1) * (basePrice * 0.0005)
        const amount = Math.random() * 5 + 0.1
        bidTotal += amount
        newBids.push({
          price,
          amount,
          total: bidTotal,
        })
      }

      setAsks(newAsks)
      setBids(newBids)
      setIsLoading(false)
    }

    generateOrderBook()
  }, [symbol])

  useEffect(() => {
    // Connect to WebSocket for real-time updates
    const { disconnect } = connectToOrderBookStream(symbol, (data) => {
      if (data.symbol === symbol) {
        // Update order book with new data
        const newAsks: OrderBookEntry[] = []
        const newBids: OrderBookEntry[] = []

        // Process asks
        let askTotal = 0
        data.asks.forEach(([price, amount]) => {
          askTotal += amount
          newAsks.push({
            price,
            amount,
            total: askTotal,
          })
        })

        // Process bids
        let bidTotal = 0
        data.bids.forEach(([price, amount]) => {
          bidTotal += amount
          newBids.push({
            price,
            amount,
            total: bidTotal,
          })
        })

        if (newAsks.length > 0) {
          setAsks(newAsks)
        }

        if (newBids.length > 0) {
          setBids(newBids)
        }
      }
    })

    return () => {
      disconnect()
    }
  }, [symbol])

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between py-4">
        <CardTitle className="text-base">Order Book</CardTitle>
        <Select value={symbol} onValueChange={handleSymbolChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select asset" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
            <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
            <SelectItem value="AAPL">Apple Inc. (AAPL)</SelectItem>
            <SelectItem value="MSFT">Microsoft Corp. (MSFT)</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="mb-2 text-sm font-medium text-red-500">Asks (Sell)</h3>
              <div className="space-y-1">
                {asks.map((ask, index) => (
                  <div key={index} className="grid grid-cols-3 text-sm relative">
                    <div className="text-red-500">{ask.price.toFixed(2)}</div>
                    <div className="text-right">{ask.amount.toFixed(4)}</div>
                    <div className="text-right text-muted-foreground">{ask.total.toFixed(4)}</div>
                    <div
                      className="absolute right-0 top-0 bottom-0 bg-red-100/20"
                      style={{
                        width: `${(ask.total / maxTotal) * 100}%`,
                        zIndex: -1,
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="mb-2 text-sm font-medium text-green-500">Bids (Buy)</h3>
              <div className="space-y-1">
                {bids.map((bid, index) => (
                  <div key={index} className="grid grid-cols-3 text-sm relative">
                    <div className="text-green-500">{bid.price.toFixed(2)}</div>
                    <div className="text-right">{bid.amount.toFixed(4)}</div>
                    <div className="text-right text-muted-foreground">{bid.total.toFixed(4)}</div>
                    <div
                      className="absolute right-0 top-0 bottom-0 bg-green-100/20"
                      style={{
                        width: `${(bid.total / maxTotal) * 100}%`,
                        zIndex: -1,
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

