"use client"

import { useEffect, useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { connectToTradeStream } from "@/lib/websocket-client"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Trade = {
  id: string
  price: number
  amount: number
  total: number
  side: "buy" | "sell"
  time: string
}

export function RecentTrades() {
  const [symbol, setSymbol] = useState("BTC")
  const [trades, setTrades] = useState<Trade[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const handleSymbolChange = useCallback((value: string) => {
    setSymbol(value)
    setIsLoading(true)
  }, [])

  useEffect(() => {
    // Generate initial trades
    const initialTrades: Trade[] = []
    const now = new Date()

    for (let i = 0; i < 10; i++) {
      const time = new Date(now.getTime() - i * 30000)
      const price =
        symbol === "BTC"
          ? 68000 + Math.random() * 1000
          : symbol === "ETH"
            ? 3800 + Math.random() * 100
            : symbol === "AAPL"
              ? 170 + Math.random() * 10
              : 320 + Math.random() * 20
      const amount = Math.random() * 2

      initialTrades.push({
        id: `trade-${i}`,
        price,
        amount,
        total: price * amount,
        side: Math.random() > 0.5 ? "buy" : "sell",
        time: time.toISOString(),
      })
    }

    setTrades(initialTrades)
    setIsLoading(false)
  }, [symbol])

  useEffect(() => {
    // Connect to WebSocket for real-time updates
    const { disconnect } = connectToTradeStream(symbol, (data) => {
      if (data.symbol === symbol) {
        const newTrade: Trade = {
          id: data.id,
          price: data.price,
          amount: data.amount,
          total: data.price * data.amount,
          side: data.side,
          time: data.time,
        }

        setTrades((prev) => [newTrade, ...prev].slice(0, 10))
      }
    })

    return () => {
      disconnect()
    }
  }, [symbol])

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between py-4">
        <CardTitle className="text-base">Recent Trades</CardTitle>
        <Select value={symbol} onValueChange={handleSymbolChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select asset" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
            <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
            <SelectItem value="AAPL">Apple Inc. (AAPL)</SelectItem>
            <SelectItem value="MSFT">Microsoft Corp. (MSFT)</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left">
                  <th className="pb-2 font-medium">Price</th>
                  <th className="pb-2 font-medium text-right">Amount</th>
                  <th className="pb-2 font-medium text-right">Total</th>
                  <th className="pb-2 font-medium text-right">Time</th>
                </tr>
              </thead>
              <tbody>
                {trades.map((trade) => (
                  <tr key={trade.id} className="border-b last:border-0">
                    <td className={`py-3 ${trade.side === "buy" ? "text-green-500" : "text-red-500"}`}>
                      ${trade.price.toFixed(2)}
                    </td>
                    <td className="py-3 text-right">{trade.amount.toFixed(4)}</td>
                    <td className="py-3 text-right">${trade.total.toFixed(2)}</td>
                    <td className="py-3 text-right text-muted-foreground">
                      {new Date(trade.time).toLocaleTimeString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

