"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowDown, ArrowUp } from "lucide-react"
import { connectToMarketStream } from "@/lib/websocket-client"
import { useAuth } from "@/lib/auth-context"
import Link from "next/link"

type PortfolioItem = {
  symbol: string
  amount: number
  price: number
  change: number
  value: number
}

export function Portfolio() {
  const { user } = useAuth()
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([])
  const [totalValue, setTotalValue] = useState(0)
  const [totalChange, setTotalChange] = useState(0)
  const [totalChangePercent, setTotalChangePercent] = useState(0)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    // Initialize portfolio from user balance
    const initialPortfolio: PortfolioItem[] = []

    if (user.balance.BTC > 0) {
      initialPortfolio.push({
        symbol: "BTC",
        amount: user.balance.BTC,
        price: 68432.12,
        change: 2.34,
        value: user.balance.BTC * 68432.12,
      })
    }

    if (user.balance.ETH > 0) {
      initialPortfolio.push({
        symbol: "ETH",
        amount: user.balance.ETH,
        price: 3845.67,
        change: 1.78,
        value: user.balance.ETH * 3845.67,
      })
    }

    setPortfolio(initialPortfolio)
    setIsLoading(false)
  }, [user])

  useEffect(() => {
    if (portfolio.length === 0) return

    const total = portfolio.reduce((sum, item) => sum + item.value, 0)
    const change = portfolio.reduce((sum, item) => sum + (item.value * item.change) / 100, 0)
    const changePercent = total > 0 ? (change / (total - change)) * 100 : 0

    setTotalValue(total)
    setTotalChange(change)
    setTotalChangePercent(changePercent)
  }, [portfolio])

  useEffect(() => {
    const { disconnect } = connectToMarketStream((data) => {
      setPortfolio((prev) => {
        return prev.map((item) => {
          if (item.symbol === data.symbol) {
            const newValue = item.amount * data.price
            return {
              ...item,
              price: data.price,
              change: data.change,
              value: newValue,
            }
          }
          return item
        })
      })
    })

    return () => {
      disconnect()
    }
  }, [])

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="py-4">
          <CardTitle className="text-base">Portfolio</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center items-center py-8">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="py-4">
        <CardTitle className="text-base">Portfolio</CardTitle>
        <div className="flex items-center justify-between mt-2">
          <div className="text-2xl font-bold">
            ${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          {totalValue > 0 && (
            <div className={`flex items-center ${totalChangePercent >= 0 ? "text-green-500" : "text-red-500"}`}>
              {totalChangePercent >= 0 ? <ArrowUp className="mr-1 h-4 w-4" /> : <ArrowDown className="mr-1 h-4 w-4" />}
              {Math.abs(totalChangePercent).toFixed(2)}%
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="px-2">
        {portfolio.length === 0 ? (
          <div className="text-center py-4 text-muted-foreground">
            <p>No assets in your portfolio.</p>
            <p className="text-sm mt-1">Start trading to build your portfolio.</p>
          </div>
        ) : (
          <div className="space-y-1">
            {portfolio.map((item) => (
              <div
                key={item.symbol}
                className="flex items-center justify-between rounded-md px-3 py-2 hover:bg-muted/50 cursor-pointer"
              >
                <div>
                  <div className="font-medium">{item.symbol}</div>
                  <div className="text-xs text-muted-foreground">{item.amount.toFixed(8)} units</div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="font-medium">
                    ${item.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                  <div className={`text-xs flex items-center ${item.change >= 0 ? "text-green-500" : "text-red-500"}`}>
                    {item.change >= 0 ? <ArrowUp className="mr-1 h-3 w-3" /> : <ArrowDown className="mr-1 h-3 w-3" />}
                    {Math.abs(item.change).toFixed(2)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        <div className="mt-4 text-center">
          <Link href="/orders" className="text-sm text-primary hover:underline">
            View Transaction History
          </Link>
        </div>
      </CardContent>
    </Card>
  )
}

