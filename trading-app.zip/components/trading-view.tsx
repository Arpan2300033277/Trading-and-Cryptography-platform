"use client"

import type React from "react"

import { useEffect, useRef, useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowDown, ArrowUp } from "lucide-react"
import { connectToMarketStream } from "@/lib/websocket-client"
import { useAuth } from "@/lib/auth-context"
import { useNotification } from "@/components/notification-system"
import { tradingService } from "@/lib/trading-service"

type ChartData = {
  time: string
  price: number
}

export function TradingView() {
  const [symbol, setSymbol] = useState("BTC")
  const [price, setPrice] = useState(68432.12)
  const [change, setChange] = useState(2.34)
  const [chartData, setChartData] = useState<ChartData[]>([])
  const [buyAmount, setBuyAmount] = useState("")
  const [sellAmount, setSellAmount] = useState("")
  const [buyTotal, setBuyTotal] = useState("")
  const [sellTotal, setSellTotal] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { user, updateBalance } = useAuth()
  const { addNotification } = useNotification()

  useEffect(() => {
    // Generate initial chart data
    const initialData: ChartData[] = []
    const now = new Date()
    for (let i = 0; i < 100; i++) {
      const time = new Date(now.getTime() - (99 - i) * 60000)
      initialData.push({
        time: time.toISOString(),
        price:
          symbol === "BTC"
            ? 68000 + Math.random() * 1000
            : symbol === "ETH"
              ? 3800 + Math.random() * 100
              : symbol === "AAPL"
                ? 170 + Math.random() * 10
                : 320 + Math.random() * 20,
      })
    }
    setChartData(initialData)
    setPrice(initialData[initialData.length - 1].price)
    setChange(((initialData[initialData.length - 1].price - initialData[0].price) / initialData[0].price) * 100)

    // Reset form values
    setBuyAmount("")
    setSellAmount("")
    setBuyTotal("")
    setSellTotal("")
  }, [symbol])

  useEffect(() => {
    const { disconnect } = connectToMarketStream((data) => {
      if (data.symbol === symbol) {
        setPrice(data.price)
        setChange(data.change)
        setChartData((prev) => {
          const now = new Date().toISOString()
          const newData = [...prev, { time: now, price: data.price }]
          if (newData.length > 100) {
            return newData.slice(newData.length - 100)
          }
          return newData
        })
      }
    })

    return () => {
      disconnect()
    }
  }, [symbol])

  useEffect(() => {
    if (!canvasRef.current || chartData.length === 0) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const drawChart = () => {
      const width = canvas.width
      const height = canvas.height

      // Clear canvas
      ctx.clearRect(0, 0, width, height)

      // Find min and max prices for scaling
      const prices = chartData.map((d) => d.price)
      const minPrice = Math.min(...prices) * 0.99
      const maxPrice = Math.max(...prices) * 1.01
      const priceRange = maxPrice - minPrice

      // Draw grid
      ctx.strokeStyle = "#2d3748"
      ctx.lineWidth = 0.5

      // Horizontal grid lines
      for (let i = 0; i < 5; i++) {
        const y = height * (i / 4)
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(width, y)
        ctx.stroke()

        // Price labels
        const price = maxPrice - (i / 4) * priceRange
        ctx.fillStyle = "#a0aec0"
        ctx.font = "10px sans-serif"
        ctx.textAlign = "left"
        ctx.fillText(price.toFixed(2), 5, y - 5)
      }

      // Draw line chart
      ctx.strokeStyle = change >= 0 ? "#10b981" : "#ef4444"
      ctx.lineWidth = 2
      ctx.beginPath()

      chartData.forEach((point, i) => {
        const x = (i / (chartData.length - 1)) * width
        const y = height - ((point.price - minPrice) / priceRange) * height

        if (i === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      })

      ctx.stroke()

      // Fill area under the line
      ctx.lineTo(width, height)
      ctx.lineTo(0, height)
      ctx.closePath()
      ctx.fillStyle = change >= 0 ? "rgba(16, 185, 129, 0.1)" : "rgba(239, 68, 68, 0.1)"
      ctx.fill()
    }

    drawChart()

    // Resize handler
    const handleResize = () => {
      if (canvas.parentElement) {
        canvas.width = canvas.parentElement.clientWidth
        canvas.height = 400
        drawChart()
      }
    }

    handleResize()
    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [chartData, change])

  const handleBuyAmountChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const amount = e.target.value
      setBuyAmount(amount)

      if (amount && !isNaN(Number(amount))) {
        const total = Number(amount) * price
        setBuyTotal(total.toFixed(2))
      } else {
        setBuyTotal("")
      }
    },
    [price],
  )

  const handleBuyTotalChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const total = e.target.value
      setBuyTotal(total)

      if (total && !isNaN(Number(total))) {
        const amount = Number(total) / price
        setBuyAmount(amount.toFixed(8))
      } else {
        setBuyAmount("")
      }
    },
    [price],
  )

  const handleSellAmountChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const amount = e.target.value
      setSellAmount(amount)

      if (amount && !isNaN(Number(amount))) {
        const total = Number(amount) * price
        setSellTotal(total.toFixed(2))
      } else {
        setSellTotal("")
      }
    },
    [price],
  )

  const handleSellTotalChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const total = e.target.value
      setSellTotal(total)

      if (total && !isNaN(Number(total))) {
        const amount = Number(total) / price
        setSellAmount(amount.toFixed(8))
      } else {
        setSellAmount("")
      }
    },
    [price],
  )

  const handleBuy = async () => {
    if (!buyAmount || isNaN(Number(buyAmount)) || Number(buyAmount) <= 0) {
      addNotification({
        type: "error",
        message: "Please enter a valid amount",
      })
      return
    }

    const amount = Number(buyAmount)
    const total = Number(buyTotal)

    if (!user || user.balance.USD < total) {
      addNotification({
        type: "error",
        message: "Insufficient USD balance",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const order = await tradingService.placeOrder({
        symbol,
        type: "market",
        side: "buy",
        amount,
        price,
      })

      // Update user balance
      updateBalance("USD", -total)
      updateBalance(symbol, amount)

      addNotification({
        type: "success",
        message: `Successfully bought ${amount} ${symbol} for $${total.toFixed(2)}`,
      })

      // Reset form
      setBuyAmount("")
      setBuyTotal("")
    } catch (error) {
      console.error("Buy order failed:", error)
      addNotification({
        type: "error",
        message: "Failed to place buy order",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSell = async () => {
    if (!sellAmount || isNaN(Number(sellAmount)) || Number(sellAmount) <= 0) {
      addNotification({
        type: "error",
        message: "Please enter a valid amount",
      })
      return
    }

    const amount = Number(sellAmount)
    const total = Number(sellTotal)

    if (!user || (user.balance as any)[symbol] < amount) {
      addNotification({
        type: "error",
        message: `Insufficient ${symbol} balance`,
      })
      return
    }

    setIsSubmitting(true)

    try {
      const order = await tradingService.placeOrder({
        symbol,
        type: "market",
        side: "sell",
        amount,
        price,
      })

      // Update user balance
      updateBalance("USD", total)
      updateBalance(symbol, -amount)

      addNotification({
        type: "success",
        message: `Successfully sold ${amount} ${symbol} for $${total.toFixed(2)}`,
      })

      // Reset form
      setSellAmount("")
      setSellTotal("")
    } catch (error) {
      console.error("Sell order failed:", error)
      addNotification({
        type: "error",
        message: "Failed to place sell order",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="space-y-1">
          <CardTitle className="flex items-center gap-2">
            {symbol}
            <span className={`text-base ${change >= 0 ? "text-green-500" : "text-red-500"}`}>
              {change >= 0 ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
              {Math.abs(change).toFixed(2)}%
            </span>
          </CardTitle>
          <div className="text-2xl font-bold">
            ${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>
        <Select value={symbol} onValueChange={setSymbol}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select asset" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
            <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
            <SelectItem value="AAPL">Apple Inc. (AAPL)</SelectItem>
            <SelectItem value="MSFT">Microsoft Corp. (MSFT)</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        <div className="h-[400px] w-full">
          <canvas ref={canvasRef} className="w-full h-full"></canvas>
        </div>

        <div className="mt-6">
          <Tabs defaultValue="buy">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="buy">Buy</TabsTrigger>
              <TabsTrigger value="sell">Sell</TabsTrigger>
            </TabsList>
            <TabsContent value="buy" className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="buy-amount">Amount ({symbol})</Label>
                  <Input
                    id="buy-amount"
                    type="number"
                    placeholder="0.00"
                    value={buyAmount}
                    onChange={handleBuyAmountChange}
                    disabled={isSubmitting}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="buy-price">Price (USD)</Label>
                  <Input id="buy-price" type="number" value={price.toFixed(2)} readOnly />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="buy-total">Total (USD)</Label>
                <Input
                  id="buy-total"
                  type="number"
                  placeholder="0.00"
                  value={buyTotal}
                  onChange={handleBuyTotalChange}
                  disabled={isSubmitting}
                />
              </div>
              <div className="text-sm text-muted-foreground mb-2">Available: ${user?.balance.USD.toFixed(2)} USD</div>
              <Button
                className="w-full bg-green-600 hover:bg-green-700"
                onClick={handleBuy}
                disabled={isSubmitting || !buyAmount || Number(buyAmount) <= 0}
              >
                {isSubmitting ? "Processing..." : `Buy ${symbol}`}
              </Button>
            </TabsContent>
            <TabsContent value="sell" className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sell-amount">Amount ({symbol})</Label>
                  <Input
                    id="sell-amount"
                    type="number"
                    placeholder="0.00"
                    value={sellAmount}
                    onChange={handleSellAmountChange}
                    disabled={isSubmitting}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sell-price">Price (USD)</Label>
                  <Input id="sell-price" type="number" value={price.toFixed(2)} readOnly />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="sell-total">Total (USD)</Label>
                <Input
                  id="sell-total"
                  type="number"
                  placeholder="0.00"
                  value={sellTotal}
                  onChange={handleSellTotalChange}
                  disabled={isSubmitting}
                />
              </div>
              <div className="text-sm text-muted-foreground mb-2">
                Available: {(user?.balance as any)[symbol]?.toFixed(8) || 0} {symbol}
              </div>
              <Button
                className="w-full bg-red-600 hover:bg-red-700"
                onClick={handleSell}
                disabled={isSubmitting || !sellAmount || Number(sellAmount) <= 0}
              >
                {isSubmitting ? "Processing..." : `Sell ${symbol}`}
              </Button>
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  )
}

